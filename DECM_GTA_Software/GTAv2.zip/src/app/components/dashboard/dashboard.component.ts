import { ChangeDetectorRef, Component, ElementRef, OnInit, SimpleChanges, ViewChild, AfterViewInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { Proyect } from 'src/app/core/database/interfaces/proyects.interface';
import { DocumentsService } from 'src/app/core/services/documents/documents.service';
import { Document } from '../../core/database/interfaces/documents.interface';
import { ParsersService } from '../../core/services/parsers/parsers.service';
import { Annotation } from '../../core/database/interfaces/annotations.interface';
import { MatPaginator } from '@angular/material/paginator';
import { AnnotationsService } from '../../core/services/annotations/annotations.service';
import { LoadingService } from '../../core/services/loading/loading.service';
import { Filters, windowsClosed, windowsOpen } from 'src/app/core/tools/enums';
import { FilterFields } from './interfaces/field-filter.interface';
import { Entity } from 'src/app/core/database/interfaces/entity.interface';
import { ProyectsService } from 'src/app/core/services/proyects/proyects.service';
import { DOCUMENT } from '@angular/common'; 
import { EntitiesServiceService } from 'src/app/core/services/entities/entities-service.service';
import { timeout } from 'rxjs';
import { GazetteerService } from 'src/app/core/services/gazetteer/gazetteer.service';
import { ToponymGazetteer } from '../../core/database/interfaces/gazetteer.interface';
import { ResizeEvent } from 'angular-resizable-element';
import { MatSidenav } from '@angular/material/sidenav';
import { searchContextInMatches } from 'src/app/core/tools/filters';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit, AfterViewInit {
  toolName: String = "";
  footerMessage: string = '';
  _filterId: number = Filters.DocumentList;

  _projectId!: number;
  _project: Proyect| undefined;
  _documents: Document[] = [];
  _entities: Entity[] =[];
  _annotations: Annotation[] = [];
  _annotationsAvailable: Annotation[] = [];
  _references: ToponymGazetteer[] = [];
  _referencesOfToponym: ToponymGazetteer[] =[];
  _referencesOfToponymCount: number = 0;
  _annotationSelected!: Annotation;
  _rightContext! : string ;
  _leftContext! : string ;
  _contextSize:number = 30;
  _filterLeftContext : string = '';
  _filterRightContext : string = '';


  isLoadingAnnotations= false;
  isDownloadingMatches = false;
  isResizebleMap = false;
  isSidenavOpened = true;
  isTabDetailsSelected = true;

  _beforeDocument:number =0;
  _mainDocument:number = 0;
  _nextDocument:number = 0;

  _windowSelected: string = '';

  displayedColumns: string[] = ['Document', 'Left', 'KWC', 'Right'];
  dataSource!:any; // new MatTableDataSource<Annotation>(this._annotations);
  clickedRows = new Set<Annotation>();

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild('corpus') _corpusContainer!:ElementRef;
  _corpusContainerHTML!: HTMLElement;


  constructor(private _activatedRoute: ActivatedRoute,
    private _parseService: ParsersService,
    private _documentsService: DocumentsService,
    private _entitiesService: EntitiesServiceService,
    private _annotationsService: AnnotationsService,
    private _loadingService: LoadingService,
    private _projectService: ProyectsService,
    private _gazetteerService: GazetteerService,
    private ref: ChangeDetectorRef,
    private route: Router
    ) { }
  ngAfterViewInit(): void {
    this.onWindowClick();
  }

    public style: object = {};
    public styleMap: object = {};
    public styleContext: object = {};
    public styleCorpus: object = {};

    validate(event: ResizeEvent): boolean {
      const MIN_DIMENSIONS_PX: number = 200;
      if (
        event.rectangle.width &&
        event.rectangle.height &&
        (event.rectangle.width < MIN_DIMENSIONS_PX ||
          event.rectangle.height < MIN_DIMENSIONS_PX)
      ) {
        return false;
      }
      return true;
    }
  
    

    onResizeEnd(event: ResizeEvent): void {
      var rectangleLeft:number = event.rectangle.left - 300;
      var rectangleTop:number = event.rectangle.top - 47;


      if(!this.isSidenavOpened)     
        rectangleLeft = event.rectangle.left;
     
      
      switch(this._windowSelected)
      {
        case 'box-1':
         this.resizeInfo(event, rectangleLeft, rectangleTop);
        break;
        case 'box-2':
          this.resizeMap(event, rectangleLeft, rectangleTop);
          break
        case 'box-3':
         this.resizeCorpus(event, rectangleLeft, rectangleTop);
        break;
        case 'box-4':
          this.resizeContext(event, rectangleLeft, rectangleTop);
        break

      } 
    }

   resizeMap(event: ResizeEvent, rectangleLeft: number, rectangleTop: number){
    this.styleMap = {
      position: 'absolute',
      left: `calc(${rectangleLeft}px) `,
      top: `${rectangleTop}px`,
      width: `${event.rectangle.width}px`,
      height: `${event.rectangle.height}px`
    };
    this._loadingService.resizeMap(true);
   }

   resizeInfo(event: ResizeEvent, rectangleLeft: number, rectangleTop: number){
    this.style = {
      position: 'absolute',
      left: `calc(${rectangleLeft}px) `,
      top: `${rectangleTop}px`,
      width: `${event.rectangle.width}px`,
      height: `${event.rectangle.height}px`
    };
   }

   resizeCorpus(event: ResizeEvent, rectangleLeft: number, rectangleTop: number){
    this.styleCorpus = {
      position: 'absolute',
      left: `calc(${rectangleLeft}px) `,
      top: `${rectangleTop}px`,
      width: `${event.rectangle.width}px`,
      height: `${event.rectangle.height}px`
    };
   }

   resizeContext(event: ResizeEvent, rectangleLeft: number, rectangleTop: number){
    this.styleContext = {
      position: 'absolute',
      left: `calc(${rectangleLeft}px) `,
      top: `${rectangleTop}px`,
      width: `${event.rectangle.width}px`,
      height: `${event.rectangle.height}px`
    };
   }

   private resizeWindows(isOpen: boolean){
    var windows = Array.from(document.getElementsByClassName("example-box"));
    const enumWindowsOpen = Object.values(windowsOpen);
    const enumWindowsClose = Object.values(windowsClosed);
    windows.forEach(window => {
      var classWindow = window.getAttribute("class");
      if(!isOpen)
      {
          enumWindowsOpen.forEach(enumOpen => {
            if(classWindow?.includes(enumOpen)){
              var newClassWindow = classWindow.replace(enumOpen, enumOpen.substring(0,enumOpen.length-4)+"close");
              window.removeAttribute("class");
              window.setAttribute("class", newClassWindow);
            }
          });
      }else
      {
        enumWindowsClose.forEach(enumClose => {
          if(classWindow?.includes(enumClose)){
            var newClassWindow = classWindow.replace(enumClose, enumClose.substring(0,enumClose.length-5)+"open");
            window.removeAttribute("class");
            window.setAttribute("class", newClassWindow);
          }
        });
      }
    });
    
   }

  ngOnInit(): void {
  

    //get project id to load
    this._activatedRoute.params
      .subscribe(({id}) => {
        this._projectId = Number(id);
         
      });
    
      this._gazetteerService.getToponyms(this._projectId)
      .then(references => this._references = references);

    //load project details
    this._projectService.getProject(this._projectId)
    .then(project => {
      this._project =  project as Proyect;
    });


    //get list of entities
    this._entitiesService.getList(this._projectId)
    .subscribe(entities => {
      this._entities = entities
    });

    //load filter tool selected from footer
    this._loadingService.currentFilter.subscribe(id => {
      this._filterId = id;
      this.updateFilterTitle();
    });

    //filter by fields
    this._loadingService.applyFilterByFields.subscribe(filter =>{
      if(filter !== null)
      this.applyFilterByFields(filter);
    });

    //filter by entities
    this._loadingService.applyFilterByEntities.subscribe(entities =>{
      if(entities !== null)
        this.applyFilterByEntities(entities);
    });
    
    //loading document selected from list 
    this._loadingService.currentSelectedDocument.subscribe(id => {
       //filter the document selected form list 
       if(id!=0){


        var be= id+1;
        var before = id-1;
        this.initLoadDocument(id);
       }
    });

 
    //get documents of project
    this._documentsService.getDocuments(this._projectId)
      .subscribe(documents => {
  
        this._documents = documents;
        this._loadingService.updateCurrentDocument(this._documents[0].id!);
      });

 
  }



  private initLoadDocument(id: number){
    var documentSelected =this._documents.filter(document => {return document.id == id}  )[0];   
   
    // var nextDocument = this._documents.filter(document => {return document.id == be})[0];
   // var beforeDocument = this._documents.filter(document => {return document.id == before})[0];
    if(documentSelected !== undefined)
    this.loadingDocumentSelected(null,documentSelected, null);
  }

  private showMatchesInCorpus()
  {
    //clear last matches 
    const matchesSpans = Array.from(document.getElementsByClassName('matched'));

    matchesSpans.forEach(span => {
      span.removeAttribute("class");
      span.setAttribute("class","annotated");
    });

    //show new matches

    const annotationsSpans = Array.from(document.getElementsByClassName('annotated'));

      annotationsSpans.forEach(span => {
        const idAnn:number = Number(span.getAttribute("id"));
        if(this._annotations.find(annotation => annotation.id == idAnn))
        {
          span.removeAttribute("class");
          span.setAttribute("class","matched");
        }
      });

  }
  
  loadingDocumentSelected( beforeDocument: Document|null,mainDocument: Document,nextDocument: Document|null){

    this._annotationsService.getAnnotations(mainDocument.id!).then();;
    this._documents.forEach(document=> document.show = false);
    mainDocument.show=true;

    this._corpusContainerHTML =document.getElementById("corpus")!;

    this._corpusContainerHTML.innerHTML = "";

    this.refreshDocumentsToDisplay(beforeDocument, mainDocument, nextDocument);
   // this.getDocumentAnnotations(mainDocument.id!);
  }

  private refreshDocumentsToDisplay( beforeDocument: Document|null,mainDocument: Document,nextDocument: Document|null){
  /**
    if(beforeDocument)
    {
      this.addDocumentToContainer(beforeDocument.textContent!, beforeDocument.id!.toString());
      this._beforeDocument = beforeDocument.id!;
    }
    else
      this._beforeDocument = 0;
   
   */
   if(this._nextDocument !== mainDocument.id)
     this.addDocumentToContainer(mainDocument.textContent!, mainDocument.id!.toString());
   else
    this.addDocumentToContainer(mainDocument.textContent!, mainDocument.id!.toString());

   this._mainDocument = mainDocument.id!;

   /*
   if(nextDocument)
   {
     this.addDocumentToContainer(nextDocument.textContent!, nextDocument.id!.toString());
     this._nextDocument = nextDocument.id!;
   }
   else
     this._nextDocument = 0;

     */

     /*
   setTimeout(() => {
     document.getElementById(this._mainDocument.toString())!.scrollIntoView({block: 'start', behavior: 'smooth'});
   },300);
   */
  }

  private addDocumentToContainer(textContent: string, documentId: string){
    this._parseService.processDocument(textContent, documentId.toString(), this._entities).then(html => {
      this._corpusContainerHTML.insertAdjacentHTML('beforeend', html);
      const annotationsSpans = Array.from(document.getElementsByClassName('annotated'));

      annotationsSpans.forEach(span => {

        const idAnn:number = Number(span.getAttribute("id"));
        if(this._annotations.find(annotation => annotation.id == idAnn))
        {
          span.removeAttribute("class");
          span.setAttribute("class","matched");
        }

        span.addEventListener('click', (event) => {
          this._annotationsService.getAnnotation(Number(span.getAttribute("id")))
          .then(annotation =>{
            if(annotation){
              this._annotationSelected = annotation as Annotation;
              this.loadContextOfAnnotation();
            }
          });
        });

        span.addEventListener('dblclick', (event) => {
          const filter: FilterFields = {
            keyWords : span.getAttribute("keywords")!
          };

          this.applyFilterByFields(filter);
        });
      });
    });
    this.ref.detectChanges();
  }

  applyFilterByFields(values: FilterFields){
    this.isLoadingAnnotations = true;
    const result = this._annotationsService.getAnnotationsByFields(values, this._projectId);
    
    result.then(res =>{
      this._annotations = res? (res as Annotation[]): ([] as Annotation[]); 
      this._annotationsAvailable = this._annotations;
      this.loadAnnotationsResult();
    })
  
  }

  applyFilterByEntities(entities: Entity[]){
    this.isLoadingAnnotations = true;
    const result = this._annotationsService.getByEntitiesAndLabels(entities, this._projectId);
    
    result.then(res =>{
      this._annotations = res? (res as Annotation[]): ([] as Annotation[]); 
      this._annotationsAvailable = this._annotations;
      this.loadAnnotationsResult();
    })
  
  }

  loadAnnotationsResult()
  {
    this.showMatchesInCorpus();
    this.dataSource = new MatTableDataSource<Annotation>(this._annotationsAvailable);
    this.isLoadingAnnotations= false; 
    setTimeout(() => 
      this.dataSource.paginator = this.paginator);
    this.isLoadingAnnotations = false;
  }

  updateFilterTitle(){
    switch (this._filterId){
      case Filters.Category:
        this.toolName = "Entities and labels";
        break;

      case Filters.DocumentList:
      this.toolName = "Documents";
      break;

      case Filters.Fields:
      this.toolName = "Fields";
      break;

      case Filters.QueryBuilder:
      this.toolName = "Query Builder";
      break;
    }
  }

  onTabSelected(tabId: string){
    var tabs = Array.from(document.getElementsByClassName("tab-item"));
    if(tabId == "tab-ann-details")
     this.isTabDetailsSelected = true;
    else
     this.isTabDetailsSelected = false;

      tabs.forEach(tab => {
        tab.removeAttribute("class");
        if(tabId == tab.getAttribute("id"))
          tab.setAttribute("class", "tab-item tab-item-selected");
        else
        tab.setAttribute("class", "tab-item");
      });
       
        
  }

  onCloseWindow(){
    this._loadingService.runFilterByEntities(null);
    this._loadingService.runFilterByFields(null);
    this.route.navigate(['/projects']);
  }

  onShowReferences(references: ToponymGazetteer[]){
     this._referencesOfToponym = references;
     this._referencesOfToponymCount = references.length;
  }
  onExportMatchesToCSV()
  {
    if(this._annotationsAvailable.length == 0)
      console.log("no hay matches que exportar");
    else{
      this.isDownloadingMatches = true;
      this.footerMessage = "Getting data...";
    this._annotationsService.getToponymAnnotations(this._projectId)
    .then( async toponyms => {
      this.footerMessage = "Getting references...";
      const annotationsMatches = this._annotationsAvailable;
      await this._parseService.exportToCSV(annotationsMatches, toponyms,this._references,  this._documents, this._entities, this._contextSize);  
      this.isDownloadingMatches = false;
    });
     
    }
  }

  onWindowClick()
  {
    var elementsBox = document.getElementsByClassName("example-box");
    var boxes = Array.from(elementsBox);
    boxes.forEach(box => {
      box.addEventListener('mousedown', (event) => {
        const windowClickClass: string = box.getAttribute("class")!;
        const windowClickNumber: number = Number(box.getAttribute("class")?.split(" ")[3].split("-")[1]);
        this._windowSelected = windowClickClass.split(" ")[2];
        if(windowClickNumber!=4 ){
        box.removeAttribute("class");
       
        var lastElement = Array.from(document.getElementsByClassName("window-4"));
        const lastElementClass = lastElement[0].getAttribute("class");
      
        lastElement[0].removeAttribute("class");
        lastElement[0].setAttribute("class", lastElementClass!.replace("window-4","window-"+windowClickNumber));
        
        
        box.setAttribute("class", windowClickClass.replace("window-"+windowClickNumber, "window-4"));
        }

        this.ref.detectChanges();
      });
    });

    this.ref.detectChanges();
  }

  onSidenavClick(e: MatSidenav){
    e.toggle();
    this.isSidenavOpened = e.opened;
    this.resizeWindows(this.isSidenavOpened);
  }

  onClickAnnotationInContext(annotation:Annotation){
   this._annotationSelected =  annotation;
  
    if(this._annotationSelected.documentId == this._mainDocument)
      this.scrollToAnnotation(this._annotationSelected.id!.toString());
    else
    {
      this.initLoadDocument(this._annotationSelected.documentId);
      this.scrollToAnnotation(this._annotationSelected.id!.toString());
    }
    this.loadContextOfAnnotation();
  }

  onFilterContext(e:any){
    
    this.isLoadingAnnotations = true;
    setTimeout(() => {
      if(this._filterLeftContext != '' || this._filterRightContext != ''){
        this._annotationsAvailable = this._annotations.filter(annotation => {
          const documentToRead =this._documents.find(document => document.id == annotation.documentId);
          const documentDOM = this._parseService.getDocumentDOM(documentToRead!.textContent);
          
          return this.filterMatchByContext(annotation, documentDOM);
        });
        
       
      }
      else
        this._annotationsAvailable = this._annotations;
  
        this.loadAnnotationsResult();
    }, 300);
    
  }

  onChangeContextSize(e:any){
    this.loadContextOfAnnotation();
  }

  private scrollToAnnotation(annotationId: string){
    setTimeout(() => {
      document.getElementById(annotationId)!.scrollIntoView({block: 'center', behavior: 'smooth'});
    }, 300);
  }

  private loadContextOfAnnotation()
  {

    const documentToRead =this._documents.find(document => document.id == this._mainDocument);
    const documentDOM = this._parseService.getDocumentDOM(documentToRead!.textContent);
    
    this._rightContext = this._parseService.getRightContext(documentDOM,this._contextSize,this._annotationSelected);
    this._leftContext = this._parseService.getLeftContext(documentDOM,this._contextSize,this._annotationSelected);
  }

  private filterMatchByContext(annotation: Annotation, documentDOM: HTMLElement): boolean{
   
    var rightContext = this._parseService.getRightContext(documentDOM,this._contextSize,annotation);
    var leftContext = this._parseService.getLeftContext(documentDOM,this._contextSize,annotation);
    return searchContextInMatches(rightContext, leftContext,this._filterRightContext, this._filterLeftContext);

  }

}
