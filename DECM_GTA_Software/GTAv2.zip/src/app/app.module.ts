import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { ProyectsComponent } from './components/projects/proyects.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ProyectComponent } from './components/projects/project-detail/project-detail.component';
import { MaterialModule } from './material/material.module';
import { AppRoutingModule } from './app-routing.module';
import { ProyectCardComponent } from './components/projects/proyect-card/proyect-card.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DashboardModule } from './components/dashboard/dashboard.module';
import { HttpClientModule } from '@angular/common/http';
import { MapModule } from './components/map/map.module';
import { AnimationsComponent } from './shared/components/animations/animations.component';
import { HomeComponent } from './components/home/home.component';
import { AddProjectComponent } from './shared/components/modals/add-project/add-project.component';
import { DeleteProjectComponent } from './shared/components/modals/delete-project/delete-project.component';
import { DeleteDocumentComponent } from './shared/components/modals/delete-document/delete-document.component';

@NgModule({
  declarations: [
    AppComponent,
    ProyectsComponent,
    ProyectComponent,
    ProyectCardComponent,
    HomeComponent,
    AddProjectComponent,
    DeleteProjectComponent,
    DeleteDocumentComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    BrowserAnimationsModule,

    AppRoutingModule,
    FlexLayoutModule,
    MaterialModule,
    NgbModule,
    DashboardModule,
    MapModule,
  ],
  providers: [],
  
  bootstrap: [AppComponent]
})
export class AppModule { }
