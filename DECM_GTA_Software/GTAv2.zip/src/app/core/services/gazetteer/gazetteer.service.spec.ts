import { TestBed } from '@angular/core/testing';

import { GazetteerService } from './gazetteer.service';

describe('GazetteerService', () => {
  let service: GazetteerService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GazetteerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
