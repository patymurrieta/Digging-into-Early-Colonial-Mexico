import { AfterViewInit, Component, OnInit, ViewChild, OnChanges, SimpleChanges } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { liveQuery } from 'dexie';
import { dbInstance } from 'src/app/core/database/db';
import { Proyect } from 'src/app/core/database/interfaces/proyects.interface';
import { DocumentsService } from 'src/app/core/services/documents/documents.service';
import { ProyectsService } from 'src/app/core/services/proyects/proyects.service';

@Component({
  selector: 'app-proyects',
  templateUrl: './proyects.component.html',
  styleUrls: ['./proyects.component.css']
})
export class ProyectsComponent implements AfterViewInit{
  
  _projects: Proyect[] = []; 
  _availableProjects: Proyect[] =  [];
  proyectSelected:number=0;
  _projectToDelete!:Proyect;
  title = '';

  displayedColumns: string[] = [ 'Title','position', 'Actions'];
  dataSource!: MatTableDataSource<Proyect>;

  @ViewChild(MatPaginator) paginator!: MatPaginator;

  constructor(private _proyectService: ProyectsService,
    private _documentsService: DocumentsService
    ) { }

  ngAfterViewInit(): void {
   
   this.loadProjects();
  
  }

  loadProjects() {
    this._proyectService.getProjects()
    .then(projects => 
      {
        this._projects = projects.sort((a, b) => a.id! > b.id! ? -1 : a.id! < b.id! ? 1 : 0);
        
        this._projects.forEach( project => 
          {
            const number: number = project.id!;
            this._documentsService.getDocumentsCount(number)
            .then(count => {
              project.numberDocuments = count
            });
          });

        this._availableProjects = projects;
        this.dataSource = new MatTableDataSource<Proyect>(this._availableProjects);
    setTimeout(() => this.dataSource.paginator = this.paginator);
       
      });
  }

  identifyProyect(index: number, proyect: Proyect) {
    
    return `${proyect.id}${proyect.title}`;
  }

  refreshProjects(bnd: boolean){
    if(bnd)
    {
      this.loadProjects();
    }

  }

  onFilterProject(event:any){
    if(event.target.value != '')
    this._availableProjects = this._projects.filter(project => project.title.toLocaleLowerCase().includes(event.target.value.toLocaleLowerCase()));
    else
    this._availableProjects = this._projects;
     this.dataSource = new MatTableDataSource<Proyect>(this._availableProjects);
    setTimeout(() => this.dataSource.paginator = this.paginator);
  
  }

  projectSelectedToDelete(project: Proyect){
    this._projectToDelete = project;
  }

  projectDeleted(bndDeleted: boolean){
    if(bndDeleted)
    {
      this.loadProjects();
    }
  }
  async resetDataBase(){
    await dbInstance.resetDatabase();
  }


  async deleteDataBase(){
    await dbInstance.delete();
  }
}

