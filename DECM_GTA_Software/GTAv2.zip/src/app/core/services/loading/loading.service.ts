import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Filters } from '../../tools/enums';
import { FilterFields } from '../../../components/dashboard/interfaces/field-filter.interface';
import { Entity } from '../../database/interfaces/entity.interface';

@Injectable({
  providedIn: 'root'
})
export class LoadingService {

   percentLoading:number = 0;
  private loadingCorpusStage = new BehaviorSubject(this.percentLoading);
  currentProgress = this.loadingCorpusStage.asObservable();

  bndResizeMap:boolean = false;
  private resizeMapStage = new BehaviorSubject(this.bndResizeMap);
  currentChangeMap = this.resizeMapStage.asObservable();

  percentDownloading:number = 0;
  private downloadingCorpusStage = new BehaviorSubject(this.percentDownloading);
  currentDownloadinf = this.downloadingCorpusStage.asObservable();

  private filterSelectedStage = new BehaviorSubject(Filters.DocumentList);
  currentFilter = this.filterSelectedStage.asObservable();

  private documentSelectedStage = new BehaviorSubject(0);
  currentSelectedDocument = this.documentSelectedStage.asObservable();

  ///apply filters
  filterByFields: FilterFields| null= null;
  private filterByFieldsStage = new BehaviorSubject(this.filterByFields);
  applyFilterByFields = this.filterByFieldsStage.asObservable();

  filterByEntities: Entity[]| null= null;
  private filterByEntitiesStage = new BehaviorSubject(this.filterByEntities);
  applyFilterByEntities = this.filterByEntitiesStage.asObservable();


  constructor() { }

  updateLoadingMessage(percent: number){
    this.loadingCorpusStage.next(percent);
  }

  updateDownloadingMessage(percent: number){
    this.downloadingCorpusStage.next(percent);
  }

  updateLoadingFilter(filterId: number){
    this.filterSelectedStage.next(filterId);
  }

  updateCurrentDocument(documentId: number){
    this.documentSelectedStage.next(documentId);
  }

  resizeMap(bnd: boolean){
    this.resizeMapStage.next(bnd);
  }

  runFilterByFields(fields: FilterFields | null){
    this.filterByFieldsStage.next(fields);
  }

  runFilterByEntities(entities: Entity[] | null){
    this.filterByEntitiesStage.next(entities);
  }

}
