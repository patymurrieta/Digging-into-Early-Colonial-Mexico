import { Component, Input, OnInit } from '@angular/core';
import { Document } from 'src/app/core/database/interfaces/documents.interface';
import { Proyect } from 'src/app/core/database/interfaces/proyects.interface';
import { DocumentsService } from 'src/app/core/services/documents/documents.service';

@Component({
  selector: 'app-proyect-card',
  templateUrl: './proyect-card.component.html',
  styleUrls: ['./project-card.component.css']
})
export class ProyectCardComponent implements OnInit {

  @Input() project!:Proyect;
  size!: number;
  constructor(private _documentService: DocumentsService) { }

  ngOnInit(): void {
    
    //this.size = this.project.id!;

    var idProject:number = this.project.id!;
    //if(this.project.id !== undefined)
   // this._documentService.getDocumentsCount(idProject).subscribe(res =>{ this.size = res as number} );
  }


}
