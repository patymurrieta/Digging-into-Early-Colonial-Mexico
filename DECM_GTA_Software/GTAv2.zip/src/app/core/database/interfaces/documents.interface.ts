export interface Document{
    id?:            number;
    proyectId:      number;
    show?:           boolean;
    title:          string;
    textContent:    string;
    annotationsCount?: number;
    paragraphCount?: number;
    indexTop?: number;
}