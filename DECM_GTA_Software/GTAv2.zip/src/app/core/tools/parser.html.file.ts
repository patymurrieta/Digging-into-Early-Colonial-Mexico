import { Annotation } from '../database/interfaces/annotations.interface';
import { Entity } from '../database/interfaces/entity.interface';
export const readHtmlFile = (inputFile:File):any => {
    const temporaryFileReader = new FileReader();

    return new Promise((resolve, reject) => {
      temporaryFileReader.onerror = () => {
        temporaryFileReader.abort();
        reject(new DOMException("Problem parsing input file."));
      };

      temporaryFileReader.onload = () => {
        resolve(temporaryFileReader.result as string);
      };
      temporaryFileReader.readAsArrayBuffer(inputFile)//readAsText(inputFile);
    });
};


export const getTitleDocument = (inputFile:File):string => {
    var split = inputFile.name.split("-")[1];//split tagtog id in document name
    return split.substring(0,split.length-15);//delete extension file
};

export const readBinaryContent = (buffer: ArrayBuffer):string => {
  let view = new Uint8Array(buffer); // trata el buffer como una secuencia de enteros de 32 bits
  return  new  TextDecoder('utf-8').decode(view);  
};


export const convertStringToDOM = (content: string, id:string|undefined, annotations: Annotation[] | undefined, entities: Entity[] | undefined, bndAnnotationsIncluded: boolean): HTMLElement =>{
  var doc = new DOMParser().parseFromString(content, "text/xml");
  const documentSection = document.createElement("section");
  documentSection.setAttribute("id", id!);
  documentSection.setAttribute("class", "corpus-document-item");
  
  var paragraphs =  doc.getElementsByTagName("pre") as HTMLCollectionOf<HTMLElement>;

  var arrayElements: HTMLElement[]=[];
  if(paragraphs.length== 0){
    paragraphs = doc.getElementsByTagName("p") as HTMLCollectionOf<HTMLElement>;
    arrayElements =Array.from(paragraphs);
  }
  else
  {

    for(var count= 0; count < paragraphs.length; count++){
      var elementP = doc.createElement("p");
      var idParagraph = paragraphs[count].getAttribute("id");
      if(idParagraph!= null){
      elementP.setAttribute("id", idParagraph );
      elementP.innerHTML = paragraphs[count].innerHTML;
      elementP.innerText = paragraphs[count].innerText;
      arrayElements.push(elementP);
      }
    }
  }
  
  arrayElements.forEach(element => {
    if(bndAnnotationsIncluded){
    var paragraphWithAnnotations = processAnnotationsInParagraph(element, annotations!.filter(annotation =>  annotation.paragraph === element.getAttribute("id")), entities!);
    element.innerHTML = paragraphWithAnnotations;
    }
    documentSection.appendChild(element);
  });
  return documentSection;
}


const processAnnotationsInParagraph =(paragraph: HTMLElement, annotations: Annotation[], entities: Entity[]):string =>{
 
  var paragraphWithAnnotations:string = '';
  var paragraphContent:string = paragraph.innerText;
  if(annotations.length > 0)
  {
    var lastIndex=-1;
    for(var start= annotations.length-1; start >= 0 ; start--){
      
      if(lastIndex !== annotations[start].index)
      {
        
        if(lastIndex == -1)
          paragraphWithAnnotations = buildTextAnnotated(paragraphContent.substring(annotations[start].index,paragraphContent.length), annotations[start], getAnnotationColor(entities, annotations[start].entityCode)) + paragraphWithAnnotations;
        else
        paragraphWithAnnotations = buildTextAnnotated(paragraphContent.substring(annotations[start].index,lastIndex), annotations[start],getAnnotationColor(entities, annotations[start].entityCode)) + paragraphWithAnnotations;
  
        lastIndex = annotations[start].index;
      }else{
      console.log(`Annotación ${annotations[start].index} parrafo: ${annotations[start].paragraph}` );
      }
    
    }
    if(lastIndex!= 0)
    paragraphWithAnnotations = paragraphContent.substring(0, lastIndex)+ paragraphWithAnnotations;
    return paragraphWithAnnotations;
  }
  else
    return paragraphContent;
  
}

const buildTextAnnotated = (paragraphContent: string, annotation: Annotation, color:string): string=>{
  
  const annotationText = paragraphContent.substring(0, annotation.keyWords.length);
  const restText = paragraphContent.substring(annotation.keyWords.length, paragraphContent.length);

  var elementSpan = document.createElement("span");
  elementSpan.setAttribute("class","annotated");
  elementSpan.setAttribute("style", "background-color:" + color);
  elementSpan.setAttribute("id", annotation.id!.toString());
  elementSpan.setAttribute("keywords", annotation.keyWords);
  elementSpan.innerText = annotationText;

  return elementSpan.outerHTML + restText;
}

const getAnnotationColor =(entities: Entity[], classId: string):string =>{
  
  var entityColor: string = '';
  var entity = entities.find(entity => entity.code === classId);

  if(!entity)
    entityColor = "hsl(0, 0%, 19%)";
  else
    entityColor = entity.color!;

  return entityColor;
}
