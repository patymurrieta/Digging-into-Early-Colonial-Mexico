export const WITHOUT_LABELS: string  =  'without labels';

