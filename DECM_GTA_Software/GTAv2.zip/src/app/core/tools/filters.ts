export const searchContextInMatches = (contextRight:string, contextLeft: string, valueRightSearch: string, valueLeftSearch: string):boolean => {
    var bndLeft: boolean = true;
    var bndRight: boolean = true;

    if(valueLeftSearch != "")
        bndLeft = (contextLeft.toLocaleLowerCase().includes(valueLeftSearch.toLocaleLowerCase()))?true : false ;

    if(valueRightSearch != "")
        bndRight = (contextRight.toLocaleLowerCase().includes(valueRightSearch.toLocaleLowerCase()))?true : false ;

    return (bndLeft && bndRight )? true: false;
  };