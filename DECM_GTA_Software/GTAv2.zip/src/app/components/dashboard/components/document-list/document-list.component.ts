import { Component, Input, OnInit } from '@angular/core';
import { LoadingService } from 'src/app/core/services/loading/loading.service';
import { Document } from '../../../../core/database/interfaces/documents.interface';

@Component({
  selector: 'app-document-list',
  templateUrl: './document-list.component.html',
  styleUrls: ['./document-list.component.css']
})
export class DocumentListComponent {

  @Input("documents") _documents: Document[] = [];

  constructor(
    private _loadingService: LoadingService
  ) { }

  onClickDocument(id: number){
    this._loadingService.updateCurrentDocument(id);
  }
}
