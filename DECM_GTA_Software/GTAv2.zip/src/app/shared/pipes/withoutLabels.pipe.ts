import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
    name: 'labels'
  })
  export class WithoutLabelsPipe implements PipeTransform {
  
    transform(labels: string[]): string {
        if(labels.length == 0) 
            return 'Without Labels';
        else
            return labels.toString();
    }
  }