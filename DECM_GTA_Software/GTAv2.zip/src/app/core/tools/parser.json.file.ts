import { Annotation } from '../database/interfaces/annotations.interface';
import { Document } from '../database/interfaces/documents.interface';
import { Entity, label } from '../database/interfaces/entity.interface';

   
  export const readAnnotationsFileAsJSON = (inputFile:File):any => {
    const temporaryFileReader = new FileReader();

    return new Promise((resolve, reject) => {
      temporaryFileReader.onerror = () => {
        temporaryFileReader.abort();
        reject(new DOMException("Problem parsing input file."));
      };

      temporaryFileReader.onload = () => {
        resolve(JSON.parse((temporaryFileReader.result as string)).entities);
      };
      temporaryFileReader.readAsText(inputFile);
    });
  };

  export const readLegendsFileAsJSON = (inputFile:File):any => {
    const temporaryFileReader = new FileReader();

    return new Promise((resolve, reject) => {
      temporaryFileReader.onerror = () => {
        temporaryFileReader.abort();
        reject(new DOMException("Problem parsing input file."));
      };

      temporaryFileReader.onload = () => {
        resolve(JSON.parse((temporaryFileReader.result as string)));
      };
      temporaryFileReader.readAsText(inputFile);
    });
  };

  export const convertJSONToAnnotations = (json: any, document: Document):Annotation[] => {
    var annotations: Annotation[] =[];
    for (var object of json) {
      const labelsAnnotations = labelsOfAnnotation(object);
      annotations.push({
        index:          Number(object.offsets[0].start),
        keyWords:       object.offsets[0].text,
        documentId:     document.id!,
        projectId:      document.proyectId,
        documentName:   document.title,
        paragraph:      object.part,
        entityCode:     object.classId,
        labels:         labelsAnnotations,
      });

     
    }
      return annotations;
  };

  export const convertJSONToEntities = (json: any, projectId: number):Entity[] => {
    const entities: Entity[] =[];
    const labels: label[] = [];
    Object.keys(json).forEach(key => {
      if(key.includes("e_"))
      {
        entities.push({
          name:       json[key],
          code:       key,
          completed:  false,
          color:      getColor(),
          labels:  labels,
          projectId: projectId
        });
      }
    });
  
    return entities;
  };

  export const convertStringsToLabels = (stringLabels: string[]): label[] =>
  {
    
    const labels: label[] =[];

    stringLabels.forEach(value => {
      labels.push(
        {
          name: value,
          completed: false
        }
      );
    });
    return labels;
  };

  const labelsOfAnnotation= (val:any):string [] =>{
    var labels: string[] = [];
    for(let key in val.fields){
      labels.push(val.fields[key].value);
    }
    return labels;
  }

  const getColor = ():string =>{
  
      return "hsl(" + 360 * Math.random() + ',' +
          (25 + 70 * Math.random()) + '%,' +
          (85 + 10 * Math.random()) + '%)'
  
  }