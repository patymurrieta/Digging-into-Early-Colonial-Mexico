import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  showInputFilesInfo: boolean= false;
  showDataStorageInfo: boolean= false;
  showGazetteerSourcesDataInfo: boolean= false;
  showingInfo:boolean= false;

  infoTitle:string = '';
  infoDescription:string = '';
  infoIcon:number = 0;
  constructor() { }

  ngOnInit(): void {
  }

  hideInfo(){
    this.clear();
  }

  showInfo(id: number){
    this.infoIcon = id;
    this.clear();
    switch(id){
      case 1:
        this.showInputFilesInfo = true;
        this.infoTitle = 'Input Files';
        this.infoDescription = 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur quam, optio reprehenderit libero quae nobis? Iure libero quaerat alias cumque. Illum, cumque natus. Reprehenderit, ipsum aliquid voluptas nam corrupti sit. Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur quam, optio reprehenderit libero quae nobis? Iure libero quaerat alias cumque. Illum, cumque natus. Reprehenderit, ipsum aliquid voluptas nam corrupti sit.  Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur quam, optio reprehenderit libero quae nobis? Iure libero quaerat alias cumque. Illum, cumque natus. Reprehenderit, ipsum aliquid voluptas nam corrupti sit. Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur quam, optio reprehenderit libero quae nobis? Iure libero quaerat alias cumque. Illum, cumque natus. Reprehenderit, ipsum aliquid voluptas nam corrupti sit. Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur quam, optio reprehenderit libero quae nobis? Iure libero quaerat alias cumque. Illum, cumque natus. Reprehenderit, ipsum aliquid voluptas nam corrupti sit. Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur quam, optio reprehenderit libero quae nobis? Iure libero quaerat alias cumque. Illum, cumque natus. Reprehenderit, ipsum aliquid voluptas nam corrupti sit.';
        break;
      case 2:
        this.showDataStorageInfo = true;
        this.infoTitle = 'Data Storage';
        this.infoDescription = 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur quam, optio reprehenderit libero quae nobis? Iure libero quaerat alias cumque. Illum, cumque natus. Reprehenderit, ipsum aliquid voluptas nam corrupti sit.';

        break;
      case 3:
        this.showGazetteerSourcesDataInfo = true;
        this.infoTitle = 'Gazetteer Sources Data';
        this.infoDescription = 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur quam, optio reprehenderit libero quae nobis? Iure libero quaerat alias cumque. Illum, cumque natus. Reprehenderit, ipsum aliquid voluptas nam corrupti sit.';

        break;
      
    }
    this.showingInfo = true;
  }

  private clear(){
    this.showDataStorageInfo = false;
    this.showInputFilesInfo = false;
    this.showGazetteerSourcesDataInfo  = false;
    this.showingInfo = false;
  }
}
