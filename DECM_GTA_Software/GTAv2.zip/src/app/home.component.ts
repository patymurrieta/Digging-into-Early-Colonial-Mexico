import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  showInputFilesInfo: boolean= false;
  showDataStorageInfo: boolean= false;
  showGazetteerSourcesDataInfo: boolean= false;
  showingInfo:boolean= false;
  constructor() { }

  ngOnInit(): void {
  }

  hideInfo(){
    this.clear();
  }

  showInfo(id: number){
    this.clear();
    switch(id){
      case 1:
        this.showInputFilesInfo = true;
        break;
      case 2:
        this.showDataStorageInfo = true;
        break;
      case 3:
        this.showGazetteerSourcesDataInfo = true;
        break;
      
    }
    this.showingInfo = true;
  }

  private clear(){
    this.showDataStorageInfo = false;
    this.showInputFilesInfo = false;
    this.showGazetteerSourcesDataInfo  = false;
    this.showingInfo = false;
  }
}
