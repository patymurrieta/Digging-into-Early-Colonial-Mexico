package youilab.gallerylikepinterest;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

public class MainActivity extends AppCompatActivity {

    RecyclerView rvMain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staggered_view);

        rvMain = (RecyclerView) findViewById(R.id.rvMain);
        Bitmap[] bitmaps = getBitmaps();
        MyRecyclerAdapter myRecyclerAdapter = new MyRecyclerAdapter(bitmaps);
        StaggeredGridLayoutManager staggeredGridLayoutManager = new StaggeredGridLayoutManager(
                3,StaggeredGridLayoutManager.VERTICAL);
     //  staggeredGridLayoutManager.setGapStrategy(StaggeredGridLayoutManager.GAP_HANDLING_NONE);
        rvMain.setLayoutManager(staggeredGridLayoutManager);
        rvMain.setItemAnimator(null);
        rvMain.setAdapter(myRecyclerAdapter);

        rvMain.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
                ((StaggeredGridLayoutManager)recyclerView.getLayoutManager()).invalidateSpanAssignments();
            }
        });
    }

    private Bitmap[] getBitmaps() {
        Bitmap[] tempBitmaps = new Bitmap[50];
        tempBitmaps[0] = BitmapFactory.decodeResource(getResources(),R.drawable.uno);
        tempBitmaps[1] = BitmapFactory.decodeResource(getResources(),R.drawable.dos);
        tempBitmaps[2] = BitmapFactory.decodeResource(getResources(),R.drawable.tres);
        tempBitmaps[3] = BitmapFactory.decodeResource(getResources(),R.drawable.cuatro);
        tempBitmaps[4] = BitmapFactory.decodeResource(getResources(),R.drawable.cinco);
        tempBitmaps[5] = BitmapFactory.decodeResource(getResources(),R.drawable.seis);
        tempBitmaps[6] = BitmapFactory.decodeResource(getResources(),R.drawable.siete);
        tempBitmaps[7] = BitmapFactory.decodeResource(getResources(),R.drawable.ocho);
        tempBitmaps[8] = BitmapFactory.decodeResource(getResources(),R.drawable.nueve);
        tempBitmaps[9] = BitmapFactory.decodeResource(getResources(),R.drawable.diez);
        tempBitmaps[10] = BitmapFactory.decodeResource(getResources(),R.drawable.once);
        tempBitmaps[11] = BitmapFactory.decodeResource(getResources(),R.drawable.doce);
        tempBitmaps[12] = BitmapFactory.decodeResource(getResources(),R.drawable.trece);
        tempBitmaps[13] = BitmapFactory.decodeResource(getResources(),R.drawable.catorce);
        tempBitmaps[14] = BitmapFactory.decodeResource(getResources(),R.drawable.uno);
        tempBitmaps[15] = BitmapFactory.decodeResource(getResources(),R.drawable.dos);
        tempBitmaps[16] = BitmapFactory.decodeResource(getResources(),R.drawable.tres);
        tempBitmaps[17] = BitmapFactory.decodeResource(getResources(),R.drawable.cuatro);
        tempBitmaps[18] = BitmapFactory.decodeResource(getResources(),R.drawable.cinco);
        tempBitmaps[19] = BitmapFactory.decodeResource(getResources(),R.drawable.seis);
        tempBitmaps[20] = BitmapFactory.decodeResource(getResources(),R.drawable.siete);
        tempBitmaps[21] = BitmapFactory.decodeResource(getResources(),R.drawable.ocho);
        tempBitmaps[22] = BitmapFactory.decodeResource(getResources(),R.drawable.nueve);
        tempBitmaps[23] = BitmapFactory.decodeResource(getResources(),R.drawable.diez);
        tempBitmaps[24] = BitmapFactory.decodeResource(getResources(),R.drawable.once);
        tempBitmaps[25] = BitmapFactory.decodeResource(getResources(),R.drawable.doce);
        tempBitmaps[26] = BitmapFactory.decodeResource(getResources(),R.drawable.trece);
        tempBitmaps[27] = BitmapFactory.decodeResource(getResources(),R.drawable.catorce);
        tempBitmaps[28] = BitmapFactory.decodeResource(getResources(),R.drawable.uno);
        tempBitmaps[29] = BitmapFactory.decodeResource(getResources(),R.drawable.dos);
        tempBitmaps[30] = BitmapFactory.decodeResource(getResources(),R.drawable.tres);
        tempBitmaps[31] = BitmapFactory.decodeResource(getResources(),R.drawable.cuatro);
        tempBitmaps[32] = BitmapFactory.decodeResource(getResources(),R.drawable.cinco);
        tempBitmaps[33] = BitmapFactory.decodeResource(getResources(),R.drawable.seis);
        tempBitmaps[34] = BitmapFactory.decodeResource(getResources(),R.drawable.siete);
        tempBitmaps[35] = BitmapFactory.decodeResource(getResources(),R.drawable.ocho);
        tempBitmaps[36] = BitmapFactory.decodeResource(getResources(),R.drawable.nueve);
        tempBitmaps[37] = BitmapFactory.decodeResource(getResources(),R.drawable.diez);
        tempBitmaps[38] = BitmapFactory.decodeResource(getResources(),R.drawable.once);
        tempBitmaps[39] = BitmapFactory.decodeResource(getResources(),R.drawable.doce);
        tempBitmaps[40] = BitmapFactory.decodeResource(getResources(),R.drawable.trece);
        tempBitmaps[41] = BitmapFactory.decodeResource(getResources(),R.drawable.catorce);
        tempBitmaps[42] = BitmapFactory.decodeResource(getResources(),R.drawable.uno);
        tempBitmaps[43] = BitmapFactory.decodeResource(getResources(),R.drawable.dos);
        tempBitmaps[44] = BitmapFactory.decodeResource(getResources(),R.drawable.tres);
        tempBitmaps[45] = BitmapFactory.decodeResource(getResources(),R.drawable.cuatro);
        tempBitmaps[46] = BitmapFactory.decodeResource(getResources(),R.drawable.cinco);
        tempBitmaps[47] = BitmapFactory.decodeResource(getResources(),R.drawable.seis);
        tempBitmaps[48] = BitmapFactory.decodeResource(getResources(),R.drawable.siete);
        tempBitmaps[49] = BitmapFactory.decodeResource(getResources(),R.drawable.ocho);

        return tempBitmaps;
    }

    private class MyRecyclerAdapter extends RecyclerView.Adapter<GridHolder>{

        Bitmap[] bitmaps;

        public MyRecyclerAdapter(Bitmap[] bitmaps)
        {
            this.bitmaps=bitmaps;
        }
        
        @Override
        public GridHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(MainActivity.this).inflate(R.layout.grid_rv,parent,false);
            return new GridHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull GridHolder holder, int position) {
            Glide.with(MainActivity.this)
                    .asBitmap()
                    .load(bitmaps[position])
                    .into(holder.imageView);
            holder.textView.setText("Caption "+position);
        }

        @Override
        public int getItemCount() {
            return bitmaps.length;
        }
    }

    private class GridHolder extends RecyclerView.ViewHolder{
        ImageView imageView;
        TextView textView;

        public GridHolder(View itemView){
            super(itemView);
            imageView = itemView.findViewById(R.id.ivMainImage);
            textView = itemView.findViewById(R.id.tvCaption);
        }
    }
}
