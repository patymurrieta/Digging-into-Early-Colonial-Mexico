import { Component, Input, OnInit } from '@angular/core';
import { LoadingService } from 'src/app/core/services/loading/loading.service';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {
  _filterId!: number;

  @Input() sidenav:any;
  @Input() downloadingMessage: string = '';
  constructor(private _loadingService: LoadingService) { }

  ngOnInit(): void {
    this._loadingService.currentDownloadinf.subscribe(percent => 
      {
        if(percent > 0)
          this.downloadingMessage = "Downloading: "+percent + "% completed";
        else
          this.downloadingMessage = '';
      }
      );
    this._loadingService.currentFilter.subscribe(id => this._filterId = id);
  }

  onClickSideNavOption(option: number)
  {
     // this.sidenav.toggle();//to open again
     this._loadingService.updateLoadingFilter(option);
  }
}
