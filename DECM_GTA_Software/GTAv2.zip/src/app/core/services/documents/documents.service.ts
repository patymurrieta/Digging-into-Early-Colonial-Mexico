import { Injectable } from '@angular/core';
import { liveQuery } from 'dexie';
import { dbInstance } from '../../database/db';
import { Document } from '../../database/interfaces/documents.interface';

@Injectable({
  providedIn: 'root'
})
export class DocumentsService {
  
  constructor() {

  }

  getDocuments(proyectId: number){
     return liveQuery(async () => { return await this.listDocuments(proyectId)});
  }

  getDocumentsCount(id: any){
    const result = dbInstance.documents.where({proyectId: id}).toArray();
    return result.then(count => {return count.length});
 }


  private async listDocuments(Id: number){
    return await dbInstance.documents
      .where({
        proyectId : Id,
      })
      .toArray();
  }

  async addDocument(document: Document):Promise<number>{
    return await dbInstance.documents.add({ 
        title: document.title,
        textContent: document.textContent,
        show: false,
        proyectId: document.proyectId,
    }).then(res => {return res;});
  }

  deleteDocument(docId: number){
    const resultAnnotations = dbInstance.annotations.where({
      documentId: docId
    }).delete().then(res => console.log(res));

    const resultDocuments = dbInstance.documents.delete(docId);

    return resultDocuments;
  }
}
