import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment.prod';
import { RepositoryService } from '../../httpclient/repository.service';
import { AnnotationsService } from '../annotations/annotations.service';
import { ToponymGazetteer } from '../../database/interfaces/gazetteer.interface';
import { dbInstance } from '../../database/db';
import { LoadingService } from '../loading/loading.service';

@Injectable({
  providedIn: 'root'
})
export class GazetteerService {

  constructor(
    private _annotationsService:AnnotationsService,
    private _repoService: RepositoryService,
    private _loadingService: LoadingService
  ) { }


  refreshToponymsReferences(projectId : number){
    this._annotationsService.getToponymAnnotations(projectId)
    .then(toponyms => {this.getReferencesOfToponyms(toponyms.map(toponym => toponym.keyWords.toLocaleLowerCase()), projectId);});
  }



  getGeoJsonObject(toponyms: ToponymGazetteer[]): any{
    var fetures: object[] = [];
  
    toponyms.forEach(toponym => {
      fetures.push({
        'type': 'Feature',
        'geometry': 
          {
          'type': 'Point',
          'coordinates': [toponym.longitude, toponym.latitude]
          },
        'properties': 
          {
          'id': toponym.pk
          }
        });
    });

    return fetures;
  }

  private getReferencesOfToponyms(toponyms: string[], projectId: number){

    const dataArrToponyms = new Set(toponyms);
    const resultNotDuplicates = [...dataArrToponyms];

    
    this._repoService.getData(environment.gazetteerToponymsAPI, JSON.stringify(resultNotDuplicates))
    .then(references => {
        var toponyms: ToponymGazetteer[] = this.convertResponseToToponymsReference(references, projectId); 
        this.addToponymsOfGazetteer(toponyms).then(res =>{ 
          this._loadingService.updateLoadingMessage(102);
          console.log(res);
        });

    });
  }

  private convertResponseToToponymsReference(response: any, projectId: number): ToponymGazetteer []{
    const jsonStringReferences = JSON.stringify(response);

    const jsonReferences = JSON.parse(jsonStringReferences.replaceAll("reference-", "reference_"));

    var toponyms: ToponymGazetteer[] = jsonReferences as ToponymGazetteer[];

    toponyms.map(toponym => {
      toponym.projectId = Number(projectId);
      toponym.latitude = Number(toponym.latitude); 
      toponym.longitude = Number(toponym.longitude); 
    });

    return toponyms;
  }

  private async addToponymsOfGazetteer(toponyms: ToponymGazetteer[]):Promise<number>{
    return await dbInstance.gazetteer.bulkAdd(toponyms).then(res => {return res;});
  }

  async getToponyms(projectId: number){
    return await dbInstance.gazetteer
    .where({
      projectId : projectId,
    })
    .toArray();
  }

  async getToponym(projectId: number, id:number){
    return await dbInstance.gazetteer
            .where({
              projectId: projectId,
              pk: id
            })
            .first();
  }

  async getToponymByTerm(projectId: number, term:string){
    return await dbInstance.gazetteer
            .where({
              projectId: projectId,
            })
            .and(toponym => toponym.toponym.toLocaleLowerCase() == term.toLocaleLowerCase())
            .first();
  }

  getStringsToponymsFromDocumentTitle(documentTitle:string):string[]{
    var wordsInTitle = documentTitle.replaceAll("_"," ").split(" ");//dividir las palabras del titulo de la relación
    //sacar las palabras que no sean mayores de 4 letras para evitar palabras como "de", "y", "la", numeros, etc
    wordsInTitle = wordsInTitle.filter( word => {
        if(word.length>4)
            return true;
        else 
            return false;
    });

    return wordsInTitle;
  }

  getToponymsFromDocumentTitle(stringToponyms:string[], toponyms: ToponymGazetteer[]):ToponymGazetteer[]{
    var toponymsOfDocumentTitle: ToponymGazetteer[] = [];

    stringToponyms.forEach(toponymString => {
      const toponymsOfWordTitle:  ToponymGazetteer[] = toponyms.filter(toponym => toponym.toponym.toLocaleLowerCase() == toponymString.toLocaleLowerCase());
      if(toponymsOfWordTitle.length > 0)
        toponymsOfDocumentTitle.push(toponymsOfWordTitle[0]);
    });

    return toponymsOfDocumentTitle;
  }
}
