import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class RepositoryService {

  constructor(
    private _http: HttpClient
  ) { }


  public getData = (route: string, toponymsJSON: string)=> {
    return this._http.post(route,{toponyms: toponymsJSON}).toPromise();
  }
}
