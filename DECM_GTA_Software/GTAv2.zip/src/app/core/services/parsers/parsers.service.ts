import { Injectable } from '@angular/core';
import { PromiseExtended } from 'dexie';

import { Annotation } from '../../database/interfaces/annotations.interface';
import { Document } from '../../database/interfaces/documents.interface';
import { Entity, EntityDTO, label } from '../../database/interfaces/entity.interface';

import { convertStringToDOM, getTitleDocument, readBinaryContent, readHtmlFile } from '../../tools/parser.html.file';
import { convertJSONToAnnotations, convertJSONToEntities, convertStringsToLabels, readAnnotationsFileAsJSON, readLegendsFileAsJSON } from '../../tools/parser.json.file';

import { AnnotationsService } from '../annotations/annotations.service';
import { DocumentsService } from '../documents/documents.service';
import { EntitiesServiceService } from '../entities/entities-service.service';
import { GazetteerService } from '../gazetteer/gazetteer.service';
import { LoadingService } from '../loading/loading.service';
import { Match } from '../../database/dto/match.interface';
import { ToponymGazetteer } from '../../database/interfaces/gazetteer.interface';
import { HistoryReference } from '../../database/dto/searching.history.interface';
import { WITHOUT_LABELS } from '../../tools/constants';

@Injectable({
  providedIn: 'root'
})
export class ParsersService {

  labelsOfEntities: EntityDTO[] = [];
  downloadingData: string = '';

  constructor(private _documentService:DocumentsService,
              private _loadingService: LoadingService,
              private _entitiesService: EntitiesServiceService,
              private _annotationsService:AnnotationsService,
              private _gazetteerService: GazetteerService
           ) { }

  async parseAnnotationsJsonFile(file: File, document:Document):Promise<Annotation[]>{
    try {
      const jsonFileContents:JSON = await readAnnotationsFileAsJSON(file)  
      const annotations = convertJSONToAnnotations(jsonFileContents, document);
      return annotations;
    } catch (e) {
      console.log(e);
      return [];
    }
  }

  async parseLegendsAnnotations(file: File, projectId:number): Promise<Entity[]> {
    try {
      const jsonFileContents:JSON = await readLegendsFileAsJSON(file);
      return convertJSONToEntities(jsonFileContents, projectId);
    } catch (e) {
      console.log(e);
      return [];
    }
  }

  async parseFiles(files: File[], projectId: number){
  
    try {
      var jsonFiles = this.FilterJSONFiles(files);
      var htmlFiles = this.FilterHtmlFiles(files);

      //entities legend are added to database before all
      var annotationsLegendsFile = this.FilterAnnotationsLegendsJSONFile(files);
      var entities = await this.parseLegendsAnnotations(annotationsLegendsFile, projectId);
      
      var cont:number = 0;
     
      for(cont; cont< htmlFiles.length; cont++)
      {
        var document:Document={
          proyectId: projectId,
          title: getTitleDocument(htmlFiles[cont]),
          textContent: await readHtmlFile(htmlFiles[cont])
        }

        var annotationsFile:File = this.getAnnotationsFile(jsonFiles,document.title)[0];

        if(annotationsFile !== null)
        {
           await this._documentService.addDocument(document).then(documentId => {
            document.id = documentId;
          });                
          
          //create annotations of document
          var annotations = await this.parseAnnotationsJsonFile(annotationsFile, document);
          this.FilterLabelsOfDocument(annotations, entities);//update entities from annotations
          await this._annotationsService.addAnnotations(annotations); 
        }

        this._loadingService.updateLoadingMessage(((cont+1)*100)/htmlFiles.length);
      }

      this.UpdateLabelsOfEntities(entities,this.labelsOfEntities);
      this.labelsOfEntities = [];
      //add entities to database
      await this._entitiesService.addSet(entities);
      this._loadingService.updateLoadingMessage(101);
      this._gazetteerService.refreshToponymsReferences(projectId);
    } catch (e) {
      console.log(e);
    }
  }

  private FilterHtmlFiles(files:File[]):File[]{
    let tmpFiles:File[] =[];

    var cont:number = 0;
    for(cont; cont< files.length; cont++)
    {
      if(files[cont].type == "text/html")
      tmpFiles.push(files[cont]);    
    }
  
    return tmpFiles;
  }

  private FilterLabelsOfDocument(annotations: Annotation[], entities: Entity[]){
    var result: string[] = []; 
    
    entities.forEach(entity => {
      var entitiesLabels: string[] = [];
      annotations.filter(annotation => {

     
        if(annotation.entityCode === entity.code)
        {
          if(annotation.labels.length > 0){
            annotation.labels.forEach(label => entitiesLabels.push(label))
          }
          else if(!entitiesLabels.includes(WITHOUT_LABELS))
            entitiesLabels.push(WITHOUT_LABELS);

          return true;
        }

        return false;
      });

      //filter duplicated labels
      const dataArr = new Set(entitiesLabels.sort());
       result = [...dataArr];



       if(this.labelsOfEntities.some(entityDTO => entityDTO.code === entity.code))
       {
        var entityIndex = this.labelsOfEntities.findIndex(entityDTO => entityDTO.code === entity.code);

        result.forEach(newLabel => {
          this.labelsOfEntities[entityIndex].labels.push(newLabel);
        });

        const dataArrEntities = new Set(this.labelsOfEntities[entityIndex].labels.sort());
       const resultNotDuplicates = [...dataArrEntities];

       this.labelsOfEntities[entityIndex].labels = resultNotDuplicates;
       }else
       {
          this.labelsOfEntities.push({
            code: entity.code,
            labels: result.sort()
          });
       }
       
       
    });

    
  }

  async exportToCSV(annotations: Annotation[],projectToponyms: Annotation[], references: ToponymGazetteer[], documents: Document[], entities: Entity[], contextSize: number){
    
    var matches:Match[] =  this.convertAnnotationsToMatches(annotations,documents, entities, contextSize);
      
    await this.foundReferencesOfMatches(matches, references, projectToponyms, documents);
    this.downloadCSVFile(matches);
     
  }

  private async foundReferencesOfMatches(matches: Match[], referencesGazetteer: ToponymGazetteer[], projectToponyms: Annotation[], documents: Document[]){
    var history: HistoryReference = {};
    
    for (var index:number = 0; index<matches.length; index++){
      var match = matches[index];
    // matches.forEach(async (match, index) => {
         //find references of document title
      await new Promise(f => setTimeout(f, 10));

      if(history!.document?.toLocaleLowerCase() == match.document.toLocaleLowerCase())
      {
        this.addToponymToCSV(match,history!.documentReferences![0], 'REF1_DOC_');
        if(history.documentReferences!.length > 1)
          this.addToponymToCSV(match,history!.documentReferences![1], 'REF2_DOC_');
        else
          this.addToponymToCSV(match,undefined, 'REF2_DOC_');

      }else{
        const toponymsStringsToSearch:string[] = this._gazetteerService.getStringsToponymsFromDocumentTitle(match.document);
        const toponymsGazeetter: ToponymGazetteer[] = this._gazetteerService.getToponymsFromDocumentTitle(toponymsStringsToSearch,referencesGazetteer);
        this.addToponymToCSV(match,toponymsGazeetter[0], 'REF1_DOC_');
        if(toponymsGazeetter.length > 1)
          this.addToponymToCSV(match,toponymsGazeetter[1], 'REF2_DOC_');
        else
          this.addToponymToCSV(match,undefined, 'REF2_DOC_');
        
        history.documentReferences = toponymsGazeetter;
        history.document = match.document;
      }

      //find references of toponym
      if(history!.toponym == match.KWC.toLocaleLowerCase())
      {
        this.addToponymToCSV(match,history!.toponymReference, 'REF_Toponym_');
      }else{
        const toponymReference: ToponymGazetteer[] = referencesGazetteer.filter(toponym => toponym.toponym.toLocaleLowerCase() == match.KWC.toLocaleLowerCase());
        if(toponymReference.length > 0){
          this.addToponymToCSV(match,toponymReference[0], 'REF_Toponym_');
          history.toponym = match.KWC.toLocaleLowerCase();
          history.toponymReference = toponymReference[0];
        }
        else{
          this.addToponymToCSV(match,undefined, 'REF_Toponym_');
          history.toponym = match.KWC.toLocaleLowerCase();
          history.toponymReference = undefined;
        }
      }
    
      //find reference of right
      const numberParagraphs: number = 1; 
      const rightReference = this.getRightReference(match.index,match,match.paragraph, numberParagraphs ,referencesGazetteer, projectToponyms);
      this.addToponymToCSV(match,rightReference,'REF_KWC_Right_');

      //find reference of left
      const leftReference = this.getLeftReference(match.index,match.index, match, match.paragraph, referencesGazetteer, projectToponyms);
      this.addToponymToCSV(match,leftReference,'REF_KWC_Left_');

      this._loadingService.updateDownloadingMessage(Number(Number((index/matches.length)*100).toFixed(0)));
      
    }

    this._loadingService.updateDownloadingMessage(100);

  }

  private downloadCSVFile(matches: any[]){
    const replacer =  (key: any, value: any) => (value === null ? '' : value); // specify how you want to handle null values here
    const header = Object.keys(matches[0]);
    const csv = matches.map((row) =>
      header
        .map((fieldName: string) => JSON.stringify(row[fieldName], replacer))
        .join(',')
    );
    csv.unshift(header.join(','));
    const csvArray = csv.join('\r\n');

    const a = document.createElement('a');
    const blob = new Blob([csvArray], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);

    a.href = url;
    a.download = 'gta_export_'+Date.now()+'.csv';
    a.click();
    window.URL.revokeObjectURL(url);
    a.remove();
  }

  private getLeftReference(index: number,lastIndex:number, match: Match, paragraph: string, referencesGazetteer: ToponymGazetteer[], projectToponyms: Annotation[]): ToponymGazetteer| undefined{
    index= (index !== lastIndex)? lastIndex: index;
    var leftReference: ToponymGazetteer|undefined = undefined;

    if(projectToponyms.length > 0){
      const leftToponyms = projectToponyms.filter(toponym => { return toponym.documentName.toLocaleLowerCase() === match.document.toLocaleLowerCase() && paragraph === toponym.paragraph && toponym.index < index});
      for(var count= leftToponyms.length-1; count >= 0; count--)
      {
        const toponym = leftToponyms[count];
        leftReference = this.getReference(toponym, referencesGazetteer);
        if(leftReference !== undefined)
          break;
      }

        
      if(leftReference == undefined)
      {
        var paragraphParts: string[] =match.paragraph.split("p");
        var paragraphNumber: number = Number(paragraphParts[1]) -1;
        while( paragraphNumber >=1)
        {
          var beforeParagraph = paragraphParts[0] +"p"+ (paragraphNumber); // before paragraph
          var toponymsOfParagraph = projectToponyms.filter(toponym => toponym.documentName.toLocaleLowerCase() === match.document.toLocaleLowerCase() && toponym.paragraph === beforeParagraph)
          
          if(toponymsOfParagraph.length > 0)
          {
            
            //en caso de solo cargar el primero a la izquierda aunque no haya datos de referencia
            var lastToponym: Annotation = toponymsOfParagraph[toponymsOfParagraph.length-1];
            leftReference = this.getReference(lastToponym, referencesGazetteer);
            if(!leftReference)
              leftReference = this.createEmptyReference(lastToponym.keyWords);
            
            break;

            //en caso de que sea el primero que tenga datos de gazetteer
            /*
            leftReference = this.getReference(toponymsOfParagraph[toponymsOfParagraph.length-1], referencesGazetteer);
            if(leftReference)
              break;
              */
          }
          paragraphNumber--;

        }
        return leftReference;
      }
      else
        return leftReference;
    }
    else
      return leftReference;
  }

  private getReference(toponym: Annotation, referencesGazetteer: ToponymGazetteer[]): ToponymGazetteer | undefined{
    const references = referencesGazetteer.filter(reference => {return  reference.toponym.toLocaleLowerCase() === toponym.keyWords.toLocaleLowerCase();});
    if(references.length > 0)
      return  references[0];
    else
      return undefined;
  }

  private getRightReference(index: number, match: Match, paragraph: string, numberParagraps: number, referencesGazetteer: ToponymGazetteer[], projectToponyms: Annotation[]): ToponymGazetteer | undefined{
    var rightReference:ToponymGazetteer|undefined= undefined;
    
      if(projectToponyms.length > 0)
      {
        const rightToponyms = projectToponyms.filter(toponym => { return toponym.documentName.toLocaleLowerCase() === match.document.toLocaleLowerCase() && paragraph === toponym.paragraph && toponym.index > index});
        for(let toponym of rightToponyms)
        {
          const references = referencesGazetteer.filter(reference => {return  reference.toponym.toLocaleLowerCase() === toponym.keyWords.toLocaleLowerCase();});
          if(references.length > 0)
          {
            rightReference = references[0];
            break;
          }
        };
/*
        if(rightReference == undefined)
        {
            const paragraphParts = match.paragraph.split("p");
            if(Number(paragraphParts[1]) <= numberParagraps)
            {
              var nextParagraph = paragraphParts[0] +"p"+ (Number(paragraphParts[1]) + 1); // next paragraph
              return this.getRightReference(0, match, nextParagraph, numberParagraps, referencesGazetteer, projectToponyms);
            }else
            return rightReference;
        }
        else*/
          return rightReference;
      }else
        return rightReference;
  }

  private convertAnnotationsToMatches(annotations: Annotation[], documents: Document[], entities: Entity[], contextSize:number): Match[]{
    var matches: Match[] =[];

    var lastDocumentID: number= 0;
    var documentDOM: HTMLElement| undefined= undefined;
    for(var count= 0; count< annotations.length; count ++){

      const annotation = annotations[count];

      if(lastDocumentID !== annotation.documentId){
        const documentContext = documents.find(document => document.id === annotation.documentId);
        documentDOM = this.getDocumentDOM(documentContext!.textContent!);
        lastDocumentID = annotation.documentId;
      }
      

      const entity = entities.find(entity =>  entity.code == annotation.entityCode);

      var match: Match = {
        document: annotation.documentName,
        index: annotation.index,
        entityCode: annotation.entityCode,
        entity: (entity != undefined)?entity.name: "Not entity",
        labels: annotation.labels.toString(),
        paragraph: annotation.paragraph,
        leftContext: this.getLeftContext(documentDOM, contextSize,annotation).replace(/\\"/g, '""'),
        KWC: annotation.keyWords,
        rightContext: this.getRightContext(documentDOM, contextSize, annotation).replace(/\\"/g, '""')
      };
      
      matches.push(match);
    }

    return matches;
  }

  getDocumentDOM(arrayBuffer: any): HTMLElement
  {
    const textPlain = readBinaryContent(arrayBuffer);
    return convertStringToDOM(textPlain, undefined,undefined, undefined,false);
  } 

  getLeftContext(documentContentDOM: HTMLElement|undefined , size: number, annotation: Annotation):string
  {

    var leftContext: string = '';
    if(documentContentDOM){
      var counterWords: number= 0;
      const wordtoSearch = annotation.paragraph.includes("p")?"p": "v";

      var paragraphNumber:number = Number(annotation.paragraph.split(wordtoSearch)[1]);
      const paragrapsArray = Array.from(documentContentDOM.children);

      while(leftContext.split(" ").length <= size && paragraphNumber >= 1){
        var paragrapToSearch: string =  annotation.paragraph.split(wordtoSearch)[0]+wordtoSearch + paragraphNumber;
        var paragraphContent = paragrapsArray.find(paragraph => paragraph.getAttribute("id") === paragrapToSearch);

        var endReadParagraph = (paragraphNumber == Number(annotation.paragraph.split(wordtoSearch)[1]))?annotation.index:  paragraphContent!.textContent!.length;
        var wordsLeft:string[] = paragraphContent!.textContent!.substring( 0 , endReadParagraph).split(' ');
        
        for(var count = wordsLeft.length-1; count>=0; count--)
        {
          const word= wordsLeft[count];
          if(counterWords <= size){
            leftContext = word+ " "+ leftContext;
            counterWords++;
           }
           else
            break;
           
        }
        paragraphNumber--;
      }  
  
    }

   
    return leftContext;
  }

  getRightContext(documentContentDOM: HTMLElement|undefined , size: number, annotation: Annotation): string
  {
    
    var rightContext: string = '';
    if(documentContentDOM){
      var counterWords: number= 0;
      const wordtoSearch = annotation.paragraph.includes("p")?"p": "v";

      var paragraphNumber:number = Number(annotation.paragraph.split(wordtoSearch)[1]);
      const paragrapsArray = Array.from(documentContentDOM.children);

      while(rightContext.split(" ").length <= size && paragraphNumber <= paragrapsArray.length){
        var paragrapToSearch: string =  annotation.paragraph.split(wordtoSearch)[0]+wordtoSearch + paragraphNumber;
        var paragraphContent = paragrapsArray.find(paragraph => paragraph.getAttribute("id") === paragrapToSearch);

        var startReadParagraph = (paragraphNumber == Number(annotation.paragraph.split(wordtoSearch)[1]))?annotation.index + annotation.keyWords.length: 0;
        var wordsRight:string[] = paragraphContent!.textContent!.substring( startReadParagraph , paragraphContent!.textContent!.length).split(' ');
        
        for(const word of wordsRight)
        {
          if(counterWords < size){
            rightContext += word + " ";
            counterWords++;
           }
           else
            break;
           
        }
        paragraphNumber++;
      }  
      counterWords =0;
    }

  
    return rightContext;
  }

  private createEmptyReference(toponymName: string): ToponymGazetteer{
    var reference: ToponymGazetteer ={
      id: '',
      toponymId: '',
      projectId: 0,
      toponym: toponymName,
      latitude: 0,
      longitude: 0,
      language: '',
      country: '',
      county: '',
      state: '',
      period: '',
      pages: '',
      reference_volumen: '',
      reference_tome: '',
      reference_author: '',
      reference_id: '',
      reference_title: '',
      reference_year: '',
      reference_publisher: ''
    };

    return reference;
  }

  private addToponymToCSV(match: Match, toponym: ToponymGazetteer|undefined, title: string){
    if(toponym != undefined){
     
      if(toponym.latitude == 0 && toponym.longitude == 0){
        match[title + 'PLACE'] = toponym.toponym;
        match[title + 'LAT'] = 'EMPTY';
        match[title + 'LNG'] = 'EMPTY';
        match[title + 'BIBLIO'] = 'EMPTY';
      }else
      {
        match[title + 'PLACE'] = toponym.toponym;
        match[title + 'LAT'] = toponym.latitude;
        match[title + 'LNG'] = toponym.longitude;
        match[title + 'BIBLIO'] = toponym.reference_author + ", " + toponym.reference_title + ", Vol: " + toponym.reference_volumen + ", Tome: " + toponym.reference_tome + ", Pages:" + toponym.pages;
  
      }

    }
    else{
      match[title + 'PLACE'] = 'NO DATA';
      match[title + 'LAT'] = 'NO DATA';
      match[title + 'LNG'] = 'NO DATA';
      match[title + 'BIBLIO'] = 'NO DATA';
    }
  }

  private FilterJSONFiles(files:File[]):File[]{
    let tmpFiles:File[] =[];

    var cont:number = 0;
    for(cont; cont< files.length; cont++)
    {
      if(files[cont].type == "application/json" && files[cont].name!== "annotations-legend.json")
      tmpFiles.push(files[cont]);    
    }

    return tmpFiles;
  }

  private UpdateLabelsOfEntities(entities: Entity[], labelsOfEntities: EntityDTO[]){
    entities.forEach(entity =>
      {
        const entityDTO: EntityDTO = labelsOfEntities.find(label => label.code == entity.code)!;
      
        var newLabels: label[]=[];
        if(entityDTO.code == entity.code)
        {
          entityDTO.labels.forEach(stringLabel =>{
              newLabels.push({
                name: stringLabel,
                completed: false
              });
          });

          entity.labels = newLabels;
        }
      });
  }

  private FilterAnnotationsLegendsJSONFile(files:File[]):File{
    let tmpFile!:File;

    var cont:number = 0;
    for(cont; cont< files.length; cont++)
    {
      if(files[cont].type == "application/json" && files[cont].name === "annotations-legend.json"){
        tmpFile = files[cont];
        break;
      }
    }

    return tmpFile;
  }

  private getAnnotationsFile(jsonFiles: File[],title:string):File[]{
    return jsonFiles.filter((file)=>{
      return file.name.includes(title);
    });
  }
  
  processDocument(arrayBuffer: any,documentId:string, entities: Entity[]): PromiseExtended<string>{
    const textPlain = readBinaryContent(arrayBuffer);
    return this._annotationsService.getAnnotations(Number(documentId))
    .then(annotations => {
      return convertStringToDOM(textPlain, documentId,annotations, entities,true).outerHTML.replace(/\n/gi,"<br/>");   
    });
  }
}
