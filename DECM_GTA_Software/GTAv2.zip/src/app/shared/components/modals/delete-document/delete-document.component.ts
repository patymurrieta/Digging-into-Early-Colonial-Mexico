import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Document } from 'src/app/core/database/interfaces/documents.interface';
import { DocumentsService } from 'src/app/core/services/documents/documents.service';

@Component({
  selector: 'app-delete-document',
  templateUrl: './delete-document.component.html',
  styleUrls: ['./delete-document.component.css']
})
export class DeleteDocumentComponent implements OnInit {
  @Input() documentToDelete: Document|undefined;
  @Output() deleteDocumentEvent = new EventEmitter<boolean>();
  constructor(
    private _documentService: DocumentsService
  ) { }

  ngOnInit(): void {
  }

  deleteDocument(){
    this._documentService.deleteDocument(Number(this.documentToDelete?.id))
      .then(res => {
        this.deleteDocumentEvent.emit(true);
      });
  }
}
