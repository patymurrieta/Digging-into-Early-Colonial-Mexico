export interface Annotation{
    id?:            number;
    index:          number;
    keyWords:       string;
    documentId:     number;
    projectId:      number;
    documentName:   string;
    paragraph:      string;
    entityCode:     string;
    labels:         string[];
}