import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './dashboard.component';
import { FooterComponent } from './components/footer/footer.component';
import { ToolbarComponent } from './components/toolbar/toolbar.component';
import { DocumentListComponent } from './components/document-list/document-list.component';
import { MaterialModule } from 'src/app/material/material.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AppRoutingModule } from 'src/app/app-routing.module';
import { EntitiesFilterComponent } from './components/entities-filter/entities-filter.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { FieldsFilterComponent } from './components/fields-filter/fields-filter.component';
import { MapModule } from '../map/map.module';
import { AnimationsComponent } from '../../shared/components/animations/animations.component';
import { ResizableModule } from 'angular-resizable-element';



@NgModule({
  declarations: [
    AnimationsComponent,
    DashboardComponent,
    DocumentListComponent,
    FooterComponent,
    ToolbarComponent,
    EntitiesFilterComponent,
    FieldsFilterComponent
  ],
  imports: [
    AppRoutingModule,
    CommonModule,
    MaterialModule,
    NgbModule,
    FormsModule,
    ResizableModule,
    BrowserAnimationsModule,
    MapModule
  ],
  exports:[
    AnimationsComponent,
    DashboardComponent,
    DocumentListComponent,
    FooterComponent,
    ToolbarComponent
  ]
})
export class DashboardModule { }
