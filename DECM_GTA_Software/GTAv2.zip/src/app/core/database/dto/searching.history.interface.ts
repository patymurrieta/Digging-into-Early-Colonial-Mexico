import { ToponymGazetteer } from "../interfaces/gazetteer.interface";

export interface HistoryReference{
    document?:              string;
    documentReferences?:    ToponymGazetteer[];
    toponym?:               string;
    toponymReference?:     ToponymGazetteer;
}