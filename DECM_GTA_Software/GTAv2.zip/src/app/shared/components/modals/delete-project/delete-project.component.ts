import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Proyect } from 'src/app/core/database/interfaces/proyects.interface';
import { ProyectsService } from 'src/app/core/services/proyects/proyects.service';

@Component({
  selector: 'app-delete-project',
  templateUrl: './delete-project.component.html',
  styleUrls: ['./delete-project.component.css']
})
export class DeleteProjectComponent implements OnInit {
  projectName: string = '';
  @Input() projectToDelete: Proyect|undefined;
  @Output() deleteProjectEvent = new EventEmitter<boolean>();
  constructor(
    private _projectService: ProyectsService
  ) { }

  ngOnInit(): void {
  }

  deleteProject(){
    this._projectService.deleteProject(Number(this.projectToDelete?.id))
      .then(res => {
        console.log(res);
        this.deleteProjectEvent.emit(true);
      });
  }
}
