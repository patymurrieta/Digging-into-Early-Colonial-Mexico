export const environment = {
  production: true,
  gazetteerToponymsAPI: "https://colonialatlas.com/api/toponym",
  mapboxToken: "pk.eyJ1IjoibGVvbmFyZG9idXllciIsImEiOiJja28zZzI3eHAwcHoxMnZvdmt6cGJ1Mml1In0.pZDfODrtdGZJEsVp0X6umA"
};
