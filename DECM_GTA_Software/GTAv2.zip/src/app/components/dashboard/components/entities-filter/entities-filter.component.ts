import { Component, Input, OnInit, Renderer2 } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Entity } from 'src/app/core/database/interfaces/entity.interface';
import { AnnotationsService } from 'src/app/core/services/annotations/annotations.service';
import { EntitiesServiceService } from 'src/app/core/services/entities/entities-service.service';
import { LoadingService } from '../../../../core/services/loading/loading.service';
import { label } from '../../../../core/database/interfaces/entity.interface';

@Component({
  selector: 'app-entities-filter',
  templateUrl: './entities-filter.component.html',
  styleUrls: ['./entities-filter.component.css']
})
export class EntitiesFilterComponent implements OnInit {
  labelLessMore: string = 'lessmore_';
  _entities: Entity[] = [];
  _projectId!: number;
  @Input() isSearching = false;

  constructor(
    private _entitiesService: EntitiesServiceService,
    private _activeRouteService: ActivatedRoute,
    private _loadingService: LoadingService,
    private _renderer: Renderer2
  ) { }

  ngOnInit(): void {
    //get project id to load
    this._activeRouteService.params.subscribe(({id}) => {
      this._projectId = Number(id);
      this._entitiesService.getList(this._projectId).subscribe(entities => this._entities = entities);
    });
    
  }

  onMoreLessLabels(entity: Entity)
  {
    const checkbosElement = document.getElementById(entity.code);
    const lessmoreButton = document.getElementById(this.createId(entity.code, this.labelLessMore));

    if(entity.labelsDisplayed !== true)
    {
      this._renderer.setStyle(checkbosElement, 'display', 'block');
      this._renderer.setStyle(lessmoreButton, 'transform', 'rotate(180deg)');
      entity.labelsDisplayed = true;
    }else
    {
      this._renderer.setStyle(checkbosElement, 'display', 'none');
      this._renderer.setStyle(lessmoreButton, 'transform', 'rotate(0deg)');
      entity.labelsDisplayed = false;
    }  
  }

  onSubmit(){
    this._loadingService.runFilterByEntities(this._entities);
  }

  updateAllComplete(entitySelected: Entity) {

    entitySelected.completed = entitySelected.labels != null && entitySelected.labels.every(t => t.completed);
  }

  someComplete(entitySelected: Entity): boolean {
   
   if (entitySelected.labels == null) {
      return false;
    }


    return entitySelected.labels.filter(t => t.completed).length > 0 && !entitySelected.completed;
   
  }

  setAll(completed: boolean, entitySelected: Entity) {
   
    entitySelected.completed = true;
    if (entitySelected?.labels == null) {
      return;
    }
    entitySelected.labels.forEach(t => (t.completed = completed));

    console.log( entitySelected);
  }
  createId(code:string, tag: string){
    return `${tag}${code}`;
  }
}
