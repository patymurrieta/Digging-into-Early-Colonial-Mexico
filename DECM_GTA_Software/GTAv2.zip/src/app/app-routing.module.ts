import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProyectsComponent } from './components/projects/proyects.component';
import { ProyectComponent } from './components/projects/project-detail/project-detail.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { WithoutLabelsPipe } from './shared/pipes/withoutLabels.pipe';
import { HomeComponent } from './components/home/home.component';

const routes: Routes =[

  
  {
    path: 'home',
    component: HomeComponent
  },
  {
    path: '',
    component: HomeComponent
  },
  {
    path:'dashboard/:id',
    component: DashboardComponent
  },
  {
    path:'projects',
    component: ProyectsComponent
  },
  {
    path: 'project/:id',
    component: ProyectComponent
  },
  {
    path: '**',
    redirectTo: 'projects'
  }

];

@NgModule({
  declarations: [
    WithoutLabelsPipe
  ],
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports:[
    RouterModule,
    WithoutLabelsPipe
  ]
})
export class AppRoutingModule { }
