export interface ToponymGazetteer{
    pk?:         number
    id:         string;
    toponymId:  string; 
    projectId:  number;
    toponym:    string;
    latitude:   number;
    longitude:  number; 
    language:   string;
    country:    string;
    county:     string;
    state:      string;
    period:     string;
    pages:      string;
    reference_volumen:       string;
    reference_tome:          string;
    reference_author:        string;
    reference_id:            string;
    reference_title:         string;
    reference_year:          string;
    reference_publisher:     string;
}