export interface Proyect{
    id?:    number;
    title:  string;
    numberDocuments?: number;
}