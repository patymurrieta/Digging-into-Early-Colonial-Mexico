import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GazetteerComponent } from './pages/gazetteer/gazetteer.component';
import * as MapboxDraw from '@mapbox/mapbox-gl-draw';


@NgModule({
  declarations: [
    GazetteerComponent
  ],
  imports: [
    CommonModule
  ],
  exports:[
    GazetteerComponent
  ]
})
export class MapModule { }
