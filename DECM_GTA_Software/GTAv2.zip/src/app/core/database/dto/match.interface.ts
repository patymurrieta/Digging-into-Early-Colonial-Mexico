export interface Match extends Record<string, any>{
    document:           string;
    index:              number;
    entityCode:         string;
    entity:             string;
    labels:             string;
    paragraph:          string;
    leftContext:        string;
    KWC:                string;
    rightContext:       string;
}