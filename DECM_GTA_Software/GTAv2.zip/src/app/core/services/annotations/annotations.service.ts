import { Injectable } from '@angular/core';
import { PromiseExtended } from 'dexie';
import { dbInstance } from '../../database/db';
import { Annotation } from '../../database/interfaces/annotations.interface';
import { FilterFields } from '../../../components/dashboard/interfaces/field-filter.interface';
import { Entity } from '../../database/interfaces/entity.interface';
import { WITHOUT_LABELS } from '../../tools/constants';

@Injectable({
  providedIn: 'root'
})
export class AnnotationsService {

  private VALUE_INDEX: number= 1;
  private VALUE_PARAGRAPH: number = 2;
  private VALUE_KEYWORDS:number = 4;
  constructor() { }

  getAnnotations(documentId: number){
    const result = dbInstance.annotations.where({
      documentId : documentId,
    }).toArray();

    return result;
  }

  getToponymAnnotations(projectId: number){
      const result = dbInstance.annotations.where({
        projectId: projectId
      }).and(annotation => annotation.labels.some(label => label === "toponym"))
      .toArray();

      return result;
  }

  getAnnotation(annId: number): PromiseExtended<Annotation|undefined>{
    const result = dbInstance.annotations.where({
      id: annId
    }).first();
    return result;
  }
  
  getAnnotationsByFields(values: FilterFields, projectId: number){
    var valueFilterTable = 0;

    if(values.index)
      valueFilterTable += this.VALUE_INDEX;
    if(values.paragraphId)
      valueFilterTable += this.VALUE_PARAGRAPH;
    if(values.keyWords)
      valueFilterTable += this.VALUE_KEYWORDS;

    


    
    const result =   dbInstance.annotations.where({
      projectId: projectId
    }).and(annotation=> {
      return this.applyFilterByFields(valueFilterTable,values,annotation);
    } )
    .toArray();

    return result;
  }

  getByEntitiesAndLabels(filter: Entity[], projectId:number){
    const result = dbInstance.annotations.where({
      projectId: projectId
    }).and(annotation => this.filterAnnotationByLabels(annotation, filter)).toArray();

    return result;
  }

  async addAnnotations(annotations: Annotation[]):Promise<number>{
    return await dbInstance.annotations.bulkAdd(annotations).then(res => {return res;});
  }

  private filterAnnotationByLabels(annotation: Annotation, filters: Entity[]):boolean{
    var resultSearch = false;
    const entityFound = filters.find(entity => entity.code == annotation.entityCode);
    if(entityFound == undefined)
      return false;
    
    

    if(annotation.labels.length == 0 && entityFound.labels.some(label => label.name == WITHOUT_LABELS && label.completed ) )
      return true;

    annotation.labels.forEach(label => {
      const labelFound = entityFound.labels.find(labelEntityFound => labelEntityFound.name == label);

      if(labelFound != undefined && labelFound.completed)
        resultSearch = true;
      else
        resultSearch = false;
    });
    return resultSearch;
  }

  private applyFilterByFields(filterValue : number,filterParams: FilterFields, annotation: Annotation):boolean{
    var result = false;
    switch(filterValue){
      case 1:
        result = (filterParams.index == annotation.index)? true: false;
      break;

      case 2:
        result = (filterParams.paragraphId === annotation.paragraph)? true: false;
      break;

      case 3:
        result = (filterParams.index == annotation.index && filterParams.paragraphId === annotation.paragraph)? true: false; 
      break;

      case 4:
        result = (annotation.keyWords.toLocaleLowerCase().includes(filterParams.keyWords!.toLocaleLowerCase()) )? true: false;
      break; 

      case 5: 
        result = (annotation.keyWords.toLocaleLowerCase().includes(filterParams.keyWords!.toLocaleLowerCase()) && filterParams.index == annotation.index)? true: false;
      break; 
      case 6: 
        result = (annotation.keyWords.toLocaleLowerCase().includes(filterParams.keyWords!.toLocaleLowerCase()) && filterParams.paragraphId === annotation.paragraph)?true: false;
        break;
      case 7:
        result = (annotation.keyWords.toLocaleLowerCase().includes(filterParams.keyWords!.toLocaleLowerCase()) && filterParams.paragraphId === annotation.paragraph && filterParams.index == annotation.index )? true: false;
    }

    return result;
  }

}


