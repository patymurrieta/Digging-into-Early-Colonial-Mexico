import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EntitiesFilterComponent } from './entities-filter.component';

describe('EntitiesFilterComponent', () => {
  let component: EntitiesFilterComponent;
  let fixture: ComponentFixture<EntitiesFilterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EntitiesFilterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EntitiesFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
