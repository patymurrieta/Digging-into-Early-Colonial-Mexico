import { Injectable } from '@angular/core';
import { liveQuery, PromiseExtended } from 'dexie';
import { dbInstance, GTADB } from '../../database/db';
import { Document } from '../../database/interfaces/documents.interface';
import { Proyect } from '../../database/interfaces/proyects.interface';

@Injectable({
  providedIn: 'root'
})
export class ProyectsService {
  

  
  constructor() { }

  async addProyect(name: string): Promise<number>{
    return await dbInstance.proyects.add({
      title: name
    }).then(res => {return res;});
  } 

  getProjects(){
    const result = dbInstance.proyects.toArray();

    return result;
  }
  getProject(projectId: number){
    const result = dbInstance.proyects.where({
      id: projectId
    }).first();
    return result;
  }

  deleteProject(id: number){
    const resultEntities = dbInstance.entities.where({
      projectId: id
    }).delete().then(res => console.log(res));

    const resultGazetteer = dbInstance.gazetteer.where({
      projectId: id
    }).delete().then(res => console.log(res));

    const resultAnnotations = dbInstance.annotations.where({
      projectId: id
    }).delete().then(res => console.log(res));

    const resultDocuments = dbInstance.documents.where({
      proyectId: id
    }).delete().then(res => console.log(res));

    const resultProject = dbInstance.proyects.delete(id);

    return resultProject;
  }
}
