import { Component, Input, OnInit } from '@angular/core';
import { FilterFields } from '../../interfaces/field-filter.interface';
import { LoadingService } from '../../../../core/services/loading/loading.service';

@Component({
  selector: 'app-fields-filter',
  templateUrl: './fields-filter.component.html',
  styleUrls: ['./fields-filter.component.css']
})
export class FieldsFilterComponent implements OnInit {

  filterFields: FilterFields= {};
  @Input() isSearching: boolean = false

  constructor(
    private _loadingService: LoadingService
  ) { }

  ngOnInit(): void {
  }

  onSubmit(){
    this._loadingService.runFilterByFields(this.filterFields);
  }
}
