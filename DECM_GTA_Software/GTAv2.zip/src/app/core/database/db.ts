import Dexie, {Table} from "dexie";
import { Proyect } from './interfaces/proyects.interface';
import { Annotation } from './interfaces/annotations.interface';
import { ToponymGazetteer } from './interfaces/gazetteer.interface';
import { Document } from "./interfaces/documents.interface";
import { Entity } from './interfaces/entity.interface';

export class GTADB extends Dexie{
    proyects!:    Table<Proyect, number>;
    documents!:   Table<Document, number>;
    annotations!: Table<Annotation, number>;
    entities!:    Table<Entity, number>;     
    gazetteer!:   Table<ToponymGazetteer, number>;

    constructor(){
        super('database');
        this.version(3).stores({
            proyects: '++id',
            documents: '++id, proyectId',
            annotations: '++id, documentId, projectId',
            entities: '++id, projectId',
            gazetteer: '++pk, projectId'
        });
    }

    async resetDatabase() {
        await dbInstance.transaction('rw', 'proyects', 'documents','annotations', 'entities', 'gazetteer', () => {
          this.proyects.clear();
          this.documents.clear();
          this.annotations.clear();
          this.entities.clear();
          this.gazetteer.clear();
        });
      }
}

export const dbInstance = new GTADB();