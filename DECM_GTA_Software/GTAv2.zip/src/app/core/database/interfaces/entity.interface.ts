export interface Entity{
    id?:            number;
    projectId:      number;
    name:           string;
    completed:      boolean;
    code:           string;
    color?:         string;
    labels:         label[];
    labelsDisplayed?: boolean;
}

export interface label{
    name:       string;
    completed: boolean;
}

export interface EntityDTO{
    code: string;
    labels: string[];
}
