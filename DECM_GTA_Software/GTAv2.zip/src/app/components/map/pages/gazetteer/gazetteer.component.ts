import { AfterViewInit, Component, OnInit, Input, OnChanges, SimpleChanges, Output, EventEmitter } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import *  as mapboxgl from 'mapbox-gl';
import { ToponymGazetteer } from 'src/app/core/database/interfaces/gazetteer.interface';
import { GazetteerService } from 'src/app/core/services/gazetteer/gazetteer.service';
import { environment } from '../../../../../environments/environment';
import { GeoJson } from '../../../../core/database/interfaces/geojsonpoint.interface';
import { LoadingService } from 'src/app/core/services/loading/loading.service';
import { Observable } from 'rxjs';
import { Annotation } from '../../../../core/database/interfaces/annotations.interface';
import { ElementSchemaRegistry } from '@angular/compiler';
import * as MapboxDraw from '@mapbox/mapbox-gl-draw';


@Component({
  selector: 'app-gazetteer',
  templateUrl: './gazetteer.component.html',
  styles: [
    `
      #map{
        height: 100%;
        width: 100%;
        overflow: none;
      }
    `
    ]
})
export class GazetteerComponent implements AfterViewInit, OnChanges {
  
  repositoryToponyms: ToponymGazetteer[] =[];
  availableToponyms: ToponymGazetteer[] =[];
  loadedMap: boolean = false;
  map!: mapboxgl.Map;
  projectId!: number;

  mapControls:any = null;
  drawPolygonsControls: any = null;

  @Input() annToSearch! : Annotation;
  @Output() toponymsEvent = new EventEmitter<ToponymGazetteer[]>();
  toponymToShow! : ToponymGazetteer;
  toponymsMatches: ToponymGazetteer[] = [];

  popup = new mapboxgl.Popup({
    closeButton: true,
    closeOnClick: true
    });
  constructor(
    private _gazeteerService: GazetteerService,
   private  _activatedRoute: ActivatedRoute,
   private _loadingService: LoadingService,
   private _gazetteerService: GazetteerService
  ) { }



  ngOnChanges(changes: SimpleChanges): void {

    
    this.toponymsMatches = this.repositoryToponyms
      .filter(toponym => {
        return toponym.toponym.toLocaleLowerCase() === this.annToSearch.keyWords.toLocaleLowerCase();
      });

    if(this.toponymsMatches.length > 0){
    this.showReferencePopup(this.toponymsMatches[0]);
    }
    else if(this.annToSearch){

      this.toponymsMatches = this.getToponymsByDocumentTitle(this.annToSearch.documentName);
      if(this.toponymsMatches.length > 0)
      {
        this.showReferencePopup(this.toponymsMatches[0]);
      }else
      this.clearPopup();
    }
    
    this.toponymsEvent.emit(this.toponymsMatches);

  }

  

  ngAfterViewInit(): void {
    //load firt time map
    this._loadingService.currentChangeMap.subscribe(stateResize => {
      if(stateResize){
       this.initMap();
      }
    });

    (mapboxgl as any ).accessToken = environment.mapboxToken;

    //reload when window resize
    this._activatedRoute.params.subscribe(({id}) => {
      this.projectId = Number(id);
      this._gazeteerService.getToponyms(Number(id))
        .then(toponyms => {
          this.repositoryToponyms = toponyms;
          this.availableToponyms = toponyms;
          this.initMap();
        });
    });
  }

  initMap(){

    setTimeout(() => {
      this.loadedMap = true;
    this.map = new mapboxgl.Map({
      container: 'map',
      style: 'mapbox://styles/mapbox/light-v10',
      center: [-100.9878424, 22.1480983],
      zoom: 1,
      maxZoom: 18
    });
 

   

    var geojson =this._gazeteerService.getGeoJsonObject(this.repositoryToponyms);
    this.loadGeojsonToMap(geojson);
  
    if(this.mapControls ==  null)
    this.mapControls = new mapboxgl.NavigationControl();
    else
      this.map.removeControl(this.mapControls);

    this.map.addControl(this.mapControls, 'bottom-right');

    if(this.drawPolygonsControls ==  null)
    {
  
      
      this.drawPolygonsControls = new MapboxDraw({
        displayControlsDefault: false,
        controls: {
          polygon: true,
          trash: true
          },
          // Set mapbox-gl-draw to draw by default.
          // The user does not have to click the polygon control button first.
          defaultMode: 'draw_polygon'
      });
    }
    else
      this.map.removeControl(this.drawPolygonsControls);

    this.map.addControl(this.drawPolygonsControls, 'bottom-left');
    
    this.map.on('draw.create', this.updateArea);
    this.map.on('draw.delete', this.updateArea);
    this.map.on('draw.update', this.updateArea);
    this.map.resize();

    }, 100);

  }

  private updateArea(){
    console.log("drawing");
  }

  private loadGeojsonToMap(geojsonFeatures: any){
    this.map.on('load', () => {
      // Add an image to use as a custom marker
      this.map.loadImage(
      'https://docs.mapbox.com/mapbox-gl-js/assets/custom_marker.png',
      (error, image) => {
      if (error) throw error;
      this.map.addImage('custom-marker', image!);
      // Add a GeoJSON source with toponyms
      this.addSource(geojsonFeatures);
       
      this.addLayer();
    });

     this.popUpConfig();
    });
  }

  private addSource(geojsonFeatures: any )
  {
    this.map.addSource('points', {
      'type': 'geojson',
      'data': 
        {
          'type': 'FeatureCollection',
          'features': 
            geojsonFeatures
        }
      });
  }

  private addLayer()
  {
    // Add a symbol layer
    this.map.addLayer({
      'id': 'points',
      'type': 'circle',
      'source': 'points',
      'paint': {
        'circle-color': '#0671b8',
        'circle-radius': 5,
        'circle-stroke-width': 1,
        'circle-stroke-color': '#ffffff'
      }
      });
  }

  popUpConfig()
  {
    
    //events over map of points
    this.map.on('click', 'points', (e:any) => {
    // Change the cursor style as a UI indicator.
    this.map.getCanvas().style.cursor = 'wait';
    this.popup.remove();


    // Copy coordinates array.
    const coordinates = e.features[0].geometry.coordinates.slice();
    //Get toponym data
    this._gazeteerService.getToponym(this.projectId, e.features[0].properties.id)
      .then(toponym => {

          // Ensure that if the map is zoomed out such that multiple
        // copies of the feature are visible, the popup appears
        // over the copy being pointed to.
        while (Math.abs(e.lngLat.lng - coordinates[0]) > 180) {
          coordinates[0] += e.lngLat.lng > coordinates[0] ? 360 : -360;
          }
      
          
        this.flyTo(toponym!);
        // Populate the popup and set its coordinates
        // based on the feature found.
        this.popup.setLngLat(coordinates).setHTML(this.createPopupHTML(toponym!)).addTo(this.map);
        this.map.getCanvas().style.cursor = 'pointer';
      });
    });
      
    this.map.on('mouseleave', 'points', () => {
    this.map.getCanvas().style.cursor = '';
    });

    this.map.on('mouseover', 'points', () => {
      
      this.map.getCanvas().style.cursor = 'pointer';
    });
  }

  clearPopup(){
    if(this.map)
     this.flyToSky();
    this.popup.remove();
  }

  showReferencePopup(reference: ToponymGazetteer)
  {
    // Change the cursor style as a UI indicator.
    this.flyTo(reference);
    this.map.getCanvas().style.cursor = 'wait';
    this.popup.remove();

    this.popup.setLngLat([reference.longitude, reference.latitude]).setHTML(this.createPopupHTML(reference)).addTo(this.map);
    this.map.getCanvas().style.cursor = 'pointer';
    
  }

  flyTo(reference: ToponymGazetteer){
    this.map.flyTo({
      center: new mapboxgl.LngLat(reference.longitude,reference.latitude),
      zoom: 14
    });
  }

  flyToSky(){
    this.map.flyTo({
      zoom: 1
    });
  }

  private createPopupHTML(toponym: ToponymGazetteer):string{

    return ' <div class="popup-container">'+
    '<div class="row">'+
      '<div class="col-12"><h4 class="reference-toponym">'+toponym.toponym+'</h4></div>'+
      '<div class="col-12"><h4 class="reference-detail">Lat: <span class="reference-detail-value">'+toponym.latitude+'</span></h4></div>'+
      '<div class="col-12"><h4 class="reference-detail">Lng: <span class="reference-detail-value">'+toponym.longitude+'</span></h4></div>'+
      '<div class="col-12"><h4 class="reference-detail">Country: <span class="reference-detail-value">'+toponym.country+'</span></h4></div>'+
      '<div class="col-12"><h4 class="reference-detail">County: <span class="reference-detail-value">'+toponym.county+'</span></h4></div>'+
      '<div class="col-12"><h4 class="reference-detail">State: <span class="reference-detail-value">'+toponym.state+'</span></h4></div>'+
      '<div class="col-12"><h4 class="reference-detail">Language: <span class="reference-detail-value">'+toponym.language+'</span></h4></div>'+
      '<div class="col-12"><h4 class="reference-detail">Reference Title: <span class="reference-detail-value">'+toponym.reference_title+'</span></h4></div>'+
      '<div class="col-12"><h4 class="reference-detail">Reference Author: <span class="reference-detail-value">'+toponym.reference_author+'</span></h4></div>'+
      '<div class="col-12"><h4 class="reference-detail">Tome: '+toponym.reference_tome+', Volumen: '+toponym.reference_volumen+', Year: '+toponym.reference_year+'</h4></div>'+
      '<div class="col-12"><h4 class="reference-detail">Reference Publisher: <span class="reference-detail-value">'+toponym.reference_publisher+'</span></h4></div>'+
      '<div class="col-12"><h4 class="reference-detail">Pages: <span class="reference-detail-value">'+toponym.pages+'</span></h4></div>'+
    '</div>'+
  '</div>';
  }

  private getToponymsByDocumentTitle(title: string){
    const toponymsStringsToSearch:string[] = this._gazetteerService.getStringsToponymsFromDocumentTitle(title);
    return this._gazetteerService.getToponymsFromDocumentTitle(toponymsStringsToSearch,this.repositoryToponyms);
  }
}
