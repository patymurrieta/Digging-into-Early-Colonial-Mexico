import { TestBed } from '@angular/core/testing';

import { ParsersService } from './parsers.service';

describe('ParsersService', () => {
  let service: ParsersService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ParsersService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
