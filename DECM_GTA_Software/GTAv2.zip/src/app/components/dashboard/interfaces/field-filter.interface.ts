export interface FilterFields{
    keyWords?:      string;
    paragraphId?:   string;
    index?:          number;
}