import { Injectable } from '@angular/core';
import { liveQuery } from 'dexie';
import { dbInstance } from '../../database/db';
import { Entity } from '../../database/interfaces/entity.interface';

@Injectable({
  providedIn: 'root'
})
export class EntitiesServiceService {

  constructor() { }

  getList(projectId:number){
    return liveQuery(async () => { return await this.list(projectId)});
  }

  private async list(id:number){
    return await dbInstance.entities
      .where({ projectId: id})
      .toArray();
  }

 async add(entity: Entity):Promise<number>{
   return await dbInstance.entities.add({ 
        name:   entity.name,
        code:   entity.code,
        completed: false,
        color:  entity.color,
        labels: [],
        projectId: entity.projectId
   }).then(res => {return res;});
  }

  async addSet(entities: Entity[]):Promise<number>{
    return await dbInstance.entities.bulkAdd(entities).then(res => {return res;});
   }
}
