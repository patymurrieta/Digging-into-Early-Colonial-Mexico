import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GazetteerComponent } from './gazetteer.component';

describe('GazetteerComponent', () => {
  let component: GazetteerComponent;
  let fixture: ComponentFixture<GazetteerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GazetteerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GazetteerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
