import { Component, OnInit,  Output, EventEmitter } from '@angular/core';
import { ProyectsService } from 'src/app/core/services/proyects/proyects.service';

@Component({
  selector: 'app-add-project',
  templateUrl: './add-project.component.html',
  styleUrls: ['./add-project.component.css']
})
export class AddProjectComponent implements OnInit {
  projectName!: string;
  @Output() newProjectEvent = new EventEmitter<boolean>();
  constructor(
    private _projectService: ProyectsService
  ) { }

  ngOnInit(): void {
  }

  addProject(){
    this._projectService.addProyect(this.projectName).then(res =>
      this.newProjectEvent.emit(true)
      );
  }
}
