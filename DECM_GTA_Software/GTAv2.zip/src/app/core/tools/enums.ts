export enum Filters {
    QueryBuilder = 1,
    Category,
    Fields,
    DocumentList
}

export enum windowsOpen{
    info = "window-info-width-open",
    context = "window-context-width-open",
    map = "window-map-width-open",
    corpus = "window-corpus-width-open"
}

export enum windowsClosed{
    info = "window-info-width-close",
    context = "window-context-width-close",
    map = "window-map-width-close",
    corpus = "window-corpus-width-close"
}