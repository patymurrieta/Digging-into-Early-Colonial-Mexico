import {  Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { Document } from 'src/app/core/database/interfaces/documents.interface';
import { Proyect } from 'src/app/core/database/interfaces/proyects.interface';
import { DocumentsService } from 'src/app/core/services/documents/documents.service';
import { GazetteerService } from 'src/app/core/services/gazetteer/gazetteer.service';
import { LoadingService } from 'src/app/core/services/loading/loading.service';
import { ParsersService } from 'src/app/core/services/parsers/parsers.service';
import { ProyectsService } from 'src/app/core/services/proyects/proyects.service';

@Component({
  selector: 'app-project',
  templateUrl: './project-detail.component.html',
  styleUrls: ['./project-detail.component.css']
})
export class ProyectComponent implements OnInit {

  projectId: number=0;
  _isLoading: boolean = false;
  _project: Proyect|undefined; 
  _documents:Document[] = [];
  _documentSelected: Document | undefined;
  texto: string = '';
  _documentsCount: number=0;
  _toponymsReferencesCount: number =0;

  _percent:number= 0;
  message: string = '0';
  _loadingMessage: string = 'Documents';


  displayedColumns: string[] = ['id', 'title', 'count', 'actions'];
  dataSource!:any;
  @ViewChild(MatPaginator) paginator!: MatPaginator;

  constructor(private _activatedRoute: ActivatedRoute,
    private _documentsService: DocumentsService,
    private _projectsService: ProyectsService,
    private _loadingService: LoadingService,
    private _gazetteerService: GazetteerService,
    private routeService: Router,
    private _parserService: ParsersService) { }
  
  ngOnInit(): void {
    this._activatedRoute.params.subscribe(({id}) =>{
      this.projectId = Number(id);
    });

    this._projectsService.getProject(Number(this.projectId))
    .then(project => {
      this._project = project as Proyect;
    });

    this._loadingService.currentProgress.subscribe(async percent => {
      this._percent = Math.round(percent);
      
      if (this._percent == 102){
        this.loadProjectDetails();
        this._loadingMessage = 'Documents';
        this._loadingService.updateLoadingMessage(0);
        this._isLoading = false;

      }else
      if(this._percent == 101){
        this._loadingMessage = '2 of 2: Getting gazetteer data...';
        
      }else
      if(this._percent == 100 ){
        this.loadProjectDetails();
        this._loadingMessage = '1 of 2: Processed documents...';
      }
      else if(this._percent > 0){
        this._isLoading = true;
        this._loadingMessage = '1 of 2 tasks: Processing documents...';
        this.message = `${this._percent}%`;
      }
      else if(this._percent == 0){
        this.loadProjectDetails();
        this._isLoading = false;
      }

    });

  }

  private loadProjectDetails(){  

    this._documentsService.getDocuments(this.projectId).subscribe(documents => {   
        this._documents = documents;  
        this.loadDataTable();
    });

    if(this._percent == 102 || this._percent == 0){
      this._gazetteerService.getToponyms(this.projectId)
      .then(toponyms => {
          this._toponymsReferencesCount = toponyms.length;
      });
    }
  }

  loadDataTable()
  {
    this.dataSource = new MatTableDataSource<Document>(this._documents);
    setTimeout(() => this.dataSource.paginator = this.paginator);
  }

  fileChanged(e:any) {
     this._parserService.parseFiles(e.target.files, Number(this.projectId));
  }

  onDocumentSelected(document: Document){
    this._documentSelected = document;
  }

  projectDeleted(bndDeleted: boolean)
  {
    if(bndDeleted)
    {
      this.routeService.navigate(['/projects']);
    }
  }

  documentDeleted(bndDeleted: boolean)
  {
    if(bndDeleted)
    {
      this.loadProjectDetails();
    }
  }

}